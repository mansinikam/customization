package com.ptc.windchill.uwgm.proesrv.c11n;


import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import wt.build.BuildHistory;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeOrder2;
import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildRule;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.part.WTPart;
import wt.util.WTException;
import wt.vc.VersionControlHelper;


public class DefaultModeledAttributesDelegate
implements ModeledAttributesDelegate
{
	  @SuppressWarnings("rawtypes")
	private static HashMap ModeledAttrList = new HashMap();
	  private static String cadDocNumber = "WT_CADDOC_NUMBER";
	  private static String associatedPartNumber = "WT_ASSOCIATED_PART_NUMBER";
	  private static String associatedPartName = "WT_ASSOCIATED_PART_NAME";
	  private static String ecnNumber = "ECN_NUMBER";
	  private static String associatedPartRev = "SP_WM_PART_REV";
	  private static String associatedPartIter = "SP_WM_PART_ITERATION";
	
	  private static String associatedPartView = "SP_WM_VIEW";
	  private static String associatedPartLifeCycle = "SP_WM_PART_LIFECYCLE";
	  private static String associatedPartType = "SP_WM_PART_TYPE";
	  private static String associatedPartLCState = "SP_WM_PART_LC_STATE";

	
	@SuppressWarnings("rawtypes")
	public HashMap getAvailableAttributes()
	{
		  return ModeledAttrList;
		}

	
	@SuppressWarnings("rawtypes")
	public HashMap getModeledAttributes(Collection paramCollection)
	throws WTException
	{
		  HashMap localHashMap1 = new HashMap();
		  for (Iterator localIterator = paramCollection.iterator(); localIterator
				.hasNext();)
		{
			  HashMap localHashMap2 = new HashMap();
			  EPMDocument localEPMDocument = (EPMDocument) localIterator
					.next();
			  localHashMap2.put(cadDocNumber,
					localEPMDocument.getNumber());
			  String str1 = getECNForCADDoc(localEPMDocument);
			  localHashMap2.put(ecnNumber, str1);
			
			  QueryResult localQueryResult = getActivelyAssociatedParts(localEPMDocument);
			
			  if ((localQueryResult != null)
					&& (localQueryResult.size() > 0))
			{
				  String str2 = null;
				  String str3 = null;
				  String str4 = null;
				  String str5 = null;
				  String str6 = null;
				  String str7 = null;
				  String str8 = null;
				  String str9 = null;
				  while (localQueryResult.hasMoreElements())
				{
					  WTPart localWTPart = (WTPart) localQueryResult
							.nextElement();
					  if (str2 == null)
					{
						  str2 = localWTPart.getNumber();
						}
					else
					{
						  str2 = new StringBuilder().append(str2)
								.append(" ").append(localWTPart.getNumber())
								.toString();
						}
					
					  if (str3 == null)
					{
						  str3 = localWTPart.getName();
						}
					else
					{
						  str3 = new StringBuilder().append(str3)
								.append(" ").append(localWTPart.getName())
								.toString();
						}
					
					  if (str4 == null)
					{
						  str4 = VersionControlHelper
								.getVersionIdentifier(localWTPart).getSeries()
								.getValue();
						}
					else
					{
						  str4 = new StringBuilder()
								.append(str4)
								.append(" ")
								.append(VersionControlHelper
										.getVersionIdentifier(localWTPart)
										.getSeries().getValue()).toString();
						}
					
					  if (str5 == null)
					{
						  str5 = VersionControlHelper
								.getIterationIdentifier(localWTPart)
								.getSeries().getValue();
						}
					else
					{
						  str5 = new StringBuilder()
								.append(str5)
								.append(" ")
								.append(VersionControlHelper
										.getIterationIdentifier(localWTPart)
										.getSeries().getValue()).toString();
						}
					
					  if (str8 == null)
					{
						  str8 = localWTPart.getViewName();
						}
					else
					{
						  str8 = new StringBuilder().append(str8)
								.append(" ").append(localWTPart.getViewName())
								.toString();
						}
					
					  if (str6 == null)
					{
						  str6 = localWTPart.getLifeCycleName();
						}
					else
					{
						  str6 = new StringBuilder().append(str6)
								.append(" ")
								.append(localWTPart.getLifeCycleName())
								.toString();
						}
					
					  if (str7 == null)
					{
						  str7 = localWTPart.getLifeCycleState()
								.getDisplay();
						}
					else
					{
						  str7 = new StringBuilder()
								.append(str7)
								.append(" ")
								.append(localWTPart.getLifeCycleState()
										.getDisplay()).toString();
						}
					
					  if (str9 == null)
					{
						  str9 = localWTPart.getPartType().getDisplay();
						}
					else
					{
						  str9 = new StringBuilder().append(str9)
								.append(" ")
								.append(localWTPart.getPartType().getDisplay())
								.toString();
						}
					}
				
				  localHashMap2.put(associatedPartNumber, str2);
				  localHashMap2.put(associatedPartName, str3);
				  localHashMap2.put(associatedPartRev, str4);
				  localHashMap2.put(associatedPartIter, str5);
				  localHashMap2.put(associatedPartView, str8);
				  localHashMap2.put(associatedPartLifeCycle, str6);
				  localHashMap2.put(associatedPartType, str9);
				  localHashMap2.put(associatedPartLCState, str7);
				}
			
			  localHashMap1.put(localEPMDocument, localHashMap2);
			}
		
		  return localHashMap1;
		}

	
	private QueryResult getActivelyAssociatedParts(
			EPMDocument paramEPMDocument)
	throws WTException
	{
		  QueryResult localQueryResult = null;
		  if (VersionControlHelper.isLatestIteration(paramEPMDocument))
		{
			  localQueryResult = PersistenceHelper.manager.navigate(
					paramEPMDocument, "buildTarget", EPMBuildRule.class);
			}
		else
		{
			  localQueryResult = PersistenceHelper.manager.navigate(
					paramEPMDocument, "built", BuildHistory.class);
			}
		
		  return localQueryResult;
		}

	
	public String getECNForCADDoc(EPMDocument paramEPMDocument)
			throws WTException
	{
		  StringBuilder localStringBuilder = new StringBuilder(256);
		
		  WTHashSet localWTHashSet = new WTHashSet();
		  localWTHashSet.addAll(ChangeHelper2.service
				.getLatestUniqueAffectingChangeOrders(paramEPMDocument));
		  localWTHashSet.addAll(ChangeHelper2.service
				.getLatestUniqueImplementedChangeOrders(paramEPMDocument));
		
		  for (Iterator localIterator = localWTHashSet.iterator(); localIterator
				.hasNext();) {
			Object localObject = localIterator.next();
			
			  ChangeOrder2 localChangeOrder2 = null;
			  if (localObject instanceof ObjectReference)
			{
				  Persistable localPersistable = ((ObjectReference) localObject)
						.getObject();
				  if (!(localPersistable instanceof ChangeOrder2)) {
					continue;
					}
				
				  localChangeOrder2 = (ChangeOrder2) localPersistable;
				} else {
				  if (!(localObject instanceof ChangeOrder2))
					continue;
				  localChangeOrder2 = (ChangeOrder2) localObject;
				}
			
			  if (localStringBuilder.length() == 0)
			{
				  localStringBuilder.append(localChangeOrder2
						.getNumber());
				}
			else
			{
				  localStringBuilder.append(" ");
				  localStringBuilder.append(localChangeOrder2
						.getNumber());
				}
			}
		
		  return localStringBuilder.toString();
		}

	
	static
	{
		  ModeledAttrList.put(cadDocNumber, String.class);
		  ModeledAttrList.put(associatedPartNumber, String.class);
		  ModeledAttrList.put(associatedPartName, String.class);
		  ModeledAttrList.put(ecnNumber, String.class);
		  ModeledAttrList.put(associatedPartRev, String.class);
		  ModeledAttrList.put(associatedPartIter, String.class);
		
		  ModeledAttrList.put(associatedPartView, String.class);
		  ModeledAttrList.put(associatedPartLifeCycle, String.class);
		  ModeledAttrList.put(associatedPartType, String.class);
		  ModeledAttrList.put(associatedPartLCState, String.class);
		}
	
}


 /** Location: D:\WIndchill_10.2_Jars\UwgmProesrv.jar Qualified Name:
 * com.ptc.windchill.uwgm.proesrv.c11n.DefaultModeledAttributesDelegate Java
 * Class Version: 7 (51.0) JD-Core Version: 0.5.3*/
 