package ext.customization.listener;

import wt.util.WTException;

public interface CreateProjectListener {
	public void listenForProjectCreate(Object event) throws WTException;
}




