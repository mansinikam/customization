package ext;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;

import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.lifecycle.LifeCycleHistory;
import wt.lifecycle.ObjectHistory;
import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.query.ClassAttribute;
import wt.query.QuerySpec;
import wt.query.SQLFunction;
import wt.query.SearchCondition;
import wt.query.SubSelectExpression;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WrappedTimestamp;

import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;

//ext.AdvancedQuerySpecTest.checkTest
/**
 * Method used to read global enumeration value from Sub-Type and IBA.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
public final class AdvancedQuerySpecTest implements RemoteAccess {

	public static final String STATE = "RELEASED";

	public static final String DOCSUBTYPE = "wt.doc.WTDocument";

	public static void main(String[] args) throws WTPropertyVetoException, WTException {
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("wcadmin");

		try {
			rms.invoke("readReleasedDateValue", AdvancedQuerySpecTest.class.getName(), null, new Class[] {},
					new Object[] {});
		} catch (RemoteException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// readReleasedDateValue();
	}

	/**
	 * @throws WTPropertyVetoException
	 * @throws WTException
	 * 
	 */
	public static void readReleasedDateValue() throws WTPropertyVetoException, WTException {
		// TODO Auto-generated method stub

		boolean flagAccess = SessionServerHelper.manager.isAccessEnforced();
		SessionServerHelper.manager.setAccessEnforced(false);

		QuerySpec subSelect = new QuerySpec();

		/* subSelect.getFromClause().setAliasPrefix("B"); */
		int bwtdoc = subSelect.appendClassList(WTDocument.class, false);
		int bwtdocMaster = subSelect.appendClassList(WTDocumentMaster.class, false);

		ClassAttribute subBranchIditerationInfo = new ClassAttribute(WTDocument.class, "iterationInfo.branchId");
		SQLFunction maxFunction = SQLFunction.newSQLFunction(SQLFunction.MAXIMUM, subBranchIditerationInfo);
		subSelect.appendSelect(maxFunction, new int[] { bwtdoc }, false);
		subSelect.appendWhere(new SearchCondition(WTDocument.class, "masterReference.key.id", WTDocumentMaster.class,
				"thePersistInfo.theObjectIdentifier.id"), new int[] { bwtdoc, bwtdocMaster });
		subSelect.appendGroupBy(new ClassAttribute(WTDocumentMaster.class, WTDocumentMaster.NUMBER),
				new int[] { bwtdocMaster }, false);
		subSelect.setAdvancedQueryEnabled(true);

		QuerySpec mainSpec = new QuerySpec();

		int wtdoc = mainSpec.addClassList(WTDocument.class, true);
		int objHistory = mainSpec.addClassList(ObjectHistory.class, false);
		int lcHistory = mainSpec.addClassList(LifeCycleHistory.class, false);
		int typeIndex = mainSpec.appendClassList(WTTypeDefinition.class, false);

		mainSpec.appendSelect(new ClassAttribute(LifeCycleHistory.class, "thePersistInfo.modifyStamp"),
				new int[] { lcHistory }, false);

		mainSpec.appendWhere(new SearchCondition(WTDocument.class, WTDocument.LIFE_CYCLE_STATE, SearchCondition.EQUAL,
				STATE), new int[] { wtdoc });
		mainSpec.appendAnd();

		final SearchCondition sctype = new SearchCondition(WTDocument.class, "typeDefinitionReference.key.id",
				WTTypeDefinition.class, "thePersistInfo.theObjectIdentifier.id");

		mainSpec.appendWhere(sctype, new int[] { wtdoc, typeIndex });
		mainSpec.appendAnd();

		final SearchCondition joinObjectHistoryWtDoc = new SearchCondition(ObjectHistory.class,
				"roleAObjectRef.key.id", WTDocument.class, "thePersistInfo.theObjectIdentifier.id");

		mainSpec.appendWhere(joinObjectHistoryWtDoc, new int[] { objHistory, wtdoc });
		mainSpec.appendAnd();

		final SearchCondition joinObjectHistoryLcHistory = new SearchCondition(ObjectHistory.class,
				"roleBObjectRef.key.id", LifeCycleHistory.class, "thePersistInfo.theObjectIdentifier.id");

		mainSpec.appendWhere(joinObjectHistoryLcHistory, new int[] { objHistory, lcHistory });
		mainSpec.appendAnd();

		mainSpec.appendWhere(new SearchCondition(LifeCycleHistory.class, LifeCycleHistory.ACTION,
				SearchCondition.EQUAL, "Enter_Phase"), new int[] { lcHistory });
		mainSpec.appendAnd();

		mainSpec.appendWhere(new SearchCondition(LifeCycleHistory.class, LifeCycleHistory.STATE, SearchCondition.EQUAL,
				STATE), new int[] { lcHistory });
		mainSpec.appendAnd();

		mainSpec.appendWhere(
				new SearchCondition(WTDocument.class, WTDocument.LATEST_ITERATION, SearchCondition.IS_TRUE),
				new int[] { wtdoc });
		mainSpec.appendAnd();

		SearchCondition scSWPart = new SearchCondition(WTTypeDefinition.class, "logicalIdentifier",
				SearchCondition.LIKE, "%" + DOCSUBTYPE + "%", true);
		mainSpec.appendWhere(scSWPart, new int[] { typeIndex });
		mainSpec.appendAnd();

		mainSpec.appendWhere(new SearchCondition(subBranchIditerationInfo, SearchCondition.IN, new SubSelectExpression(
				subSelect)), new int[] { wtdoc });
		mainSpec.setAdvancedQueryEnabled(true);

		final QueryResult result = PersistenceServerHelper.manager.query(mainSpec);

		System.out.println("Result Size : " + result.size());

		while (result.hasMoreElements()) {

			Object[] objs = (Object[]) result.nextElement();

			WTDocument doc = (WTDocument) objs[wtdoc];
			WrappedTimestamp stamp = (WrappedTimestamp) objs[1];
			System.out.println("The document number : " + doc);
			System.out.println("The Release Date : " + stamp);
			LOG.debug("Use logger in your actual code instead of sys out");
		}

		SessionServerHelper.manager.setAccessEnforced(flagAccess);
	}

	/**
	 * Private variable for Logger.
	 */
	private static final org.apache.log4j.Logger LOG = LogR.getLogger(AdvancedQuerySpecTest.class.getName());

}
