/**
 * Java file for Elecon Gears.
 */
package ext.datautility;

import wt.folder.Folder;

import com.ptc.core.components.rendering.guicomponents.AttributeGuiComponent;
import com.ptc.core.components.rendering.guicomponents.PrintableComponent;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 * 
 * 
 */
public class ColoredFolderDisplayComponent extends AttributeGuiComponent
		implements PrintableComponent {

	/**
	 * Default comment for field serialVersionUID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	private final Folder folder;

	/**
	 * 
	 * 
	 * @return the folder.
	 */
	public Folder getFolder() {
		return folder;
	}

	/**
	 * @param folder
	 */
	public ColoredFolderDisplayComponent(Folder folder)

	{

		this.folder = folder;

		setRenderer(new ColoredFolderDisplayComponentRenderer());

	}

	public String getPrintableValue()

	{
		return "";
	}
}
