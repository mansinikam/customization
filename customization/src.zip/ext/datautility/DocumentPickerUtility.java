package ext.datautility;

import java.util.Map;

import wt.util.WTException;

import com.ptc.core.components.descriptor.ComponentDescriptor;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.rendering.PickerRenderConfigs;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;

/**
 * Create a document picker.
 * 
 * @version 'true' 1.0
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 **/
public class DocumentPickerUtility extends AbstractDataUtility {

	public Object getDataValue(String paramString, Object paramObject,
			ModelContext paramModelContext) throws WTException {
		ComponentDescriptor componentdescriptor = paramModelContext
				.getDescriptor();
		Map<Object, Object> map = componentdescriptor.getProperties();
		Object value = paramModelContext.getRawValue();
		String attLabelName = getLabel(paramString, paramModelContext);
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.PICKER_ID, "docPicker");
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.OBJECT_TYPE, "wt.doc.WTDocument");
		/* search target object */
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.PICKER_TITLE, "Search Document");
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.READ_ONLY_TEXTBOX, "true");
		PickerRenderConfigs.setDefaultPickerProperty(map, "showTypePicker",
				"false");
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.COMPONENT_ID, " docPicker ");
		/* picker search criteria configuration */
		PickerRenderConfigs.setDefaultPickerProperty(map, "defaultHiddenValue",
				(String) value);
		PickerRenderConfigs.setDefaultPickerProperty(map, "pickedAttributes",
				"name");
		/* Picker return value to input field */
		PickerRenderConfigs.setDefaultPickerProperty(map,
				"includeTypeInstanceId", "true");
		PickerInputComponent pickerinputcomponent = new PickerInputComponent(
				attLabelName, (String) value,
				PickerRenderConfigs.getPickerConfigs(map), 30);
		pickerinputcomponent.setColumnName(AttributeDataUtilityHelper
				.getColumnName(paramString, paramObject, paramModelContext));
		pickerinputcomponent.setId(paramString);
		pickerinputcomponent.setName(paramString);
		pickerinputcomponent.setRequired(AttributeDataUtilityHelper
				.isInputRequired(paramModelContext));
		return pickerinputcomponent;
	}
}
