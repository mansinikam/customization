
package ext.datautility;

import java.util.Arrays;

import wt.util.WTException;

import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.GuiComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
//ext.datautility.CustomRichTextEditor
public class CustomRichTextEditor extends DefaultDataUtility{

	public Object getDataValue(String paramString, Object paramObject, com.ptc.core.components.descriptor.ModelContext paramModelContext) throws WTException {
		
		Object obj = super.getDataValue(paramString, paramObject, paramModelContext);
		
		AttributeInputCompositeComponent aicc = (AttributeInputCompositeComponent) obj;
		System.out.println(aicc.getValueInputComponent().getClass());
		AttributeInputComponent ai = aicc.getValueInputComponent();
		if(ai instanceof StringInputComponent){
			StringInputComponent sic = (StringInputComponent) ai;
			sic.setRichText(true);
			GUIComponentArray gca = new GUIComponentArray(Arrays.asList(new GuiComponent[]{sic}));
			return gca;
		}
		return obj;
	}
}
