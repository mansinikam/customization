/**
 * Java file for Elecon Gears.
 */
package ext.datautility;

import wt.fc.QueryResult;

import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.folder.SubFolder;
import wt.folder.SubFolderReference;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.rendering.GuiComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.IconComponent;
import com.ptc.windchill.enterprise.folder.dataUtilities.FolderNameDataUtility;

//ext.datautility.ColorFolderDataUtility
/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 * 
 * 
 */
public class ColorFolderDataUtility extends FolderNameDataUtility {

	/**
	 * Default comment for field flagEmpty.
	 */
	/*
	 * private boolean flagEmpty = true;
	 */

	@Override
	public Object getDataValue(String paramString, Object paramObject,
			ModelContext paramModelContext) throws WTException {
		Object obj = super.getDataValue(paramString, paramObject,
				paramModelContext);
		Object sub = null;
		if (paramObject instanceof SubFolderReference) {
			sub = ((SubFolderReference) paramObject).getObject();
			QueryResult result = FolderHelper.service
					.findFolderContents((SubFolder) sub);
			if (isFolderEmpty(result)) {
				GUIComponentArray gui = (GUIComponentArray) obj;
				GUIComponentArray newGui = new GUIComponentArray();
				for (int i = 0; i < gui.size(); i++) {
					GuiComponent guiComp = gui.get(i);
					if (guiComp instanceof IconComponent) {
						newGui.addGUIComponent(guiComp);
					}
				}
				newGui.addGUIComponent((new ColoredFolderDisplayComponent(
						(Folder) sub)));
				return newGui;
			}
		}
		
		return obj;
	}

	/**
	 * @param result
	 * @return boolean value.
	 * @throws WTException
	 */
	private boolean isFolderEmpty(QueryResult result) throws WTException {
		boolean flagEmpty = isFolderEmpty(result, true);
		return flagEmpty;
	}

	/**
	 * @param result
	 * @param flagEmpty
	 * @return boolean value.
	 * @throws WTException
	 */
	private boolean isFolderEmpty(QueryResult result, boolean flagEmpty)
			throws WTException {
		boolean localFlag = flagEmpty;
		while (result.hasMoreElements()) {
			if (!localFlag) {
				return localFlag;
			}
			Object obj = result.nextElement();
			if (obj instanceof SubFolder) {
				localFlag = isFolderEmpty(
						FolderHelper.service
								.findFolderContents((SubFolder) obj),
						localFlag);
			} else {
				localFlag = false;
			}
		}
		return localFlag;
	}
}
