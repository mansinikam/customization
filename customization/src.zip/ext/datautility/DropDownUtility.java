package ext.datautility;

import java.util.ArrayList;
import wt.util.WTException;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.ui.resources.ComponentMode;

/**
 * Create a drop down list.
 * 
 * @version 'true' 1.0
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 **/
public class DropDownUtility  extends DefaultDataUtility {
	public Object getDataValue(String componentId, Object datum,
			ModelContext modelContext) throws WTException {
		Object object = super.getDataValue(componentId, datum, modelContext);
		if (modelContext.getDescriptorMode().equals(ComponentMode.CREATE)) {
			if (object instanceof AttributeInputCompositeComponent) {
				ArrayList<String> displayList = new ArrayList<String>();
				displayList.add("Yes");
				displayList.add("No");
				StringInputComponent sic = new StringInputComponent(
						componentId, displayList, displayList);
				sic.setColumnName(AttributeDataUtilityHelper.getColumnName(
						componentId, datum, modelContext));
				return sic;
			}
		}
		return object;
	}
}
