package ext.datautility;

import java.util.Map;

import org.apache.log4j.Logger;

import wt.log4j.LogR;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ComponentDescriptor;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.rendering.PickerRenderConfigs;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;

/**
 * Data utility for Item(WTPart) Picker.
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * @version 'true' 1.0
 * 
 */
public class TestItemPicker extends AbstractDataUtility {
	private static final Logger LOG = LogR
			.getLogger(TestItemPicker.class.getName());
	
	public Object getDataValue(String paramString, Object paramObject,
			ModelContext paramModelContext) throws WTException {
		LOG.debug("Entering Item Picker .......");
		final int columnSize = 60;
		final ComponentDescriptor componentdescriptor = paramModelContext
				.getDescriptor();
		/*
		 * Setting different property of Picker in the Map
		 */
		final Map<Object, Object> map = componentdescriptor.getProperties();
		
		final Object value = paramModelContext.getRawValue();
		final String attLabelName = getLabel(paramString, paramModelContext);
		
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.PICKER_ID, "TestPicker");
		// This ID should be unique
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.OBJECT_TYPE, "wt.part.WTPart");
		// The Object type to search
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.PICKER_TITLE, "Search Item");
		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.READ_ONLY_TEXTBOX, "true");
		PickerRenderConfigs.setDefaultPickerProperty(map, "showTypePicker",
				"false");

		PickerRenderConfigs.setDefaultPickerProperty(map,
				PickerRenderConfigs.COMPONENT_ID, "TestPicker");


		PickerRenderConfigs.setDefaultPickerProperty(map, "defaultHiddenValue",
				(String) value);
		PickerRenderConfigs.setDefaultPickerProperty(map, "pickedAttributes",
				"number"); // Picker return value to input field
		final PickerInputComponent pickerinputcomponent = new PickerInputComponent(
				attLabelName, (String) value,
				PickerRenderConfigs.getPickerConfigs(map), columnSize);
		pickerinputcomponent.setColumnName(AttributeDataUtilityHelper
				.getColumnName(paramString, paramObject, paramModelContext));
		pickerinputcomponent.setId(paramString);
		pickerinputcomponent.setName(paramString);
		pickerinputcomponent.setRequired(AttributeDataUtilityHelper
				.isInputRequired(paramModelContext));
		return pickerinputcomponent;
	}
}
