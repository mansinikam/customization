package ext.datautility;

import wt.fc.PersistenceHelper;
import wt.pds.StatementSpec;
import wt.pom.POMInitException;
import wt.pom.PersistenceException;
import wt.pom.PersistentObjectManager;
import wt.preference.PreferenceHelper;
import wt.projmgmt.admin.Project2;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.version.WindchillVersion;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.windchill.instassm.ReleaseIdException;

public class ShowProjectSequence extends DefaultDataUtility {

	/**
	 * Overridden method of {@link DefaultDataUtility}.
	 * 
	 * @param componentId
	 *            the Component ID.
	 * 
	 * @param datum
	 *            the object upon which this data utility will worked.
	 * 
	 * @param modelContext
	 *            the object of {@link ModelContext}.
	 * 
	 * @exception WTException
	 *                throws {@link WTException}/
	 * 
	 * @return returns the object.
	 */
	@Override
	public Object getDataValue(String componentId, Object datum,
			ModelContext modelContext) throws WTException {
		System.out.println("Inside data utility");
		/*
		 * Calling the super class method.
		 */
		final Object obj = super.getDataValue(componentId, datum, modelContext);
		/*
		 * The data utility only works for ComponentMode create.
		 */
		if (modelContext.getDescriptorMode().equals(ComponentMode.CREATE)
				&& ((Boolean) PreferenceHelper.service.getValue(
						"ext/tgs/ProjectPreference", "WINDCHILL"))) {

			System.out.println("Returning the current sequence.");
			/*
			 * Returning the current sequence.
			 */
			final String seq = getCurrentSequence();
			System.out.println("Sequence Value " + seq);
			
			return seq;

		}
		/*
		 * Returning the Object.
		 */
		return obj;
	}

	private String getCurrentSequence() throws POMInitException, ReleaseIdException, PersistenceException {
		if(WindchillVersion.getInstalledAssemblyDisplayLabelsAsString().contains("10.1"))
			return getCurrentSequenceForTenOne();
		else
			return getCurrentSequenceForTenTwo();
	}

	private String getCurrentSequenceForTenOne() {
		final boolean isCreateAccess = SessionServerHelper.manager
				.isAccessEnforced();
		try{
		SessionServerHelper.manager.setAccessEnforced(false);
		return String.format("%08d", PersistenceHelper.manager
		.find((StatementSpec) new QuerySpec(Project2.class)).size());
		} catch (QueryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			SessionServerHelper.manager.setAccessEnforced(isCreateAccess);
		}
		return "";
	}

	private String getCurrentSequenceForTenTwo() throws POMInitException, PersistenceException {
		return String.format("%08d", Integer.parseInt(PersistentObjectManager.getPom()
				.getCurrentSequence("project_seq")));
				/* This code only work
		// in 10.2. For lower version use the above code */
	}
	
	
}
