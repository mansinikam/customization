package ext.datautility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.MultiValuedInputComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.ui.resources.ComponentMode;

public class DepartmentDataUtility extends DefaultDataUtility {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Object getDataValue(String component_id, Object obj, ModelContext mc)
			throws WTException {
		Object object = super.getDataValue(component_id, obj, mc);
		String colname = AttributeDataUtilityHelper.getColumnName(component_id,
				obj, mc);
		/* Generating the column name for the UI components */

		/*
		 * Querying database for all the WTDocument name and storing them in an
		 * ArrayList named displayval
		 */
		QuerySpec qs = new QuerySpec(WTDocument.class);
		QueryResult kd = PersistenceHelper.manager.find((StatementSpec) qs);
		int sz = kd.size() + 20;
		ArrayList<String> displayval = new ArrayList<String>();
		// displayval.add("");
		while (kd.hasMoreElements())
			displayval.add(((WTDocument) kd.nextElement()).getName());
		String[] arrayTemp = (String[]) displayval.toArray(new String[] {});
		arrayTemp = (String[]) new HashSet(Arrays.asList(arrayTemp))
				.toArray(new String[] {});

		displayval = new ArrayList(Arrays.asList(arrayTemp));
		/*
		 * The return type of kd.nextElement() method is Object but I need only
		 * the WTDocument name in the ArrayList. That's why I am type casting it
		 * with (WTDocument) and extract only the name using another method of
		 * WTDocument class named "getName()" Creating a StringInputComponent
		 * and the display value and the internal value as the ArrayList created
		 * above.Here for dropdown list we can't use ComboBox as the IBA is a
		 * mutivalued attribute.
		 */
		StringInputComponent sic = new StringInputComponent(component_id,
				displayval, displayval);
		sic.setIncludeBlankEntryInList(false);
		sic.setName(colname);
		sic.setColumnName(colname);

		/* checking whether the Description Mode is in Create mode */
		if (mc.getDescriptorMode().equals(ComponentMode.CREATE)) {
			if (object instanceof AttributeInputCompositeComponent) {
				ArrayList<AttributeInputComponent> aic = new ArrayList<AttributeInputComponent>(
						sz);
				/*
				 * If you change the value of sz then in the ui instead of
				 * "Plus" or "Minus" button you will get only "Plus" button or
				 * in processor only one value will be taken
				 */
				for (int i = 0; i < (sz); i++)
					aic.add((AttributeInputComponent) sic);
				// Populating the ArrayList with StringInputComponent
				/*
				 * Creating MultiValuedInputComponent whose input UI is the
				 * ArrayList of AttributeInputComponent
				 */
				MultiValuedInputComponent mvnew = new MultiValuedInputComponent(
						aic, aic.get(0));
				mvnew.setMultiValued(true);
				mvnew.setRequired(true);// If its an mandatory attribute
				mvnew.setColumnName(colname);

				return mvnew;// written by Kaushik das
			}
		} else if (mc.getDescriptorMode().equals(ComponentMode.EDIT)) {
			int visibleElement = 0;
			if (object instanceof AttributeInputCompositeComponent) {
				Object newobj = ((AttributeInputCompositeComponent) object)
						.getValueInputComponent();
				ArrayList<AttributeInputComponent> as = null;
				if (newobj instanceof MultiValuedInputComponent) {
					as = ((MultiValuedInputComponent) ((AttributeInputCompositeComponent) object)
							.getValueInputComponent()).getInputUI();
				} else if (newobj instanceof StringInputComponent) {
					as = new ArrayList<AttributeInputComponent>();
					as.add((AttributeInputComponent) (newobj));
					as.add(null);
				}
				/*
				 * Extracting the arraylist which is already associate with that
				 * selector. Later which will use to extract the previousvalues
				 */
				ArrayList<AttributeInputComponent> newas = new ArrayList<AttributeInputComponent>();
				displayval.add(0, "");
				for (int i = 0; i < (sz); i++) {
					if (i < (as.size() - 1)) {
						StringInputComponent sc = (StringInputComponent) as
								.get(i);
						String rawVal = (String) sc.getRawValue();

						if (rawVal != null) {
							visibleElement++;

							StringInputComponent newsic = new StringInputComponent(
									component_id, displayval, displayval);
							newsic.setName(colname);
							newsic.setIncludeBlankEntryInList(false);
							newsic.setColumnName(colname);
							newsic.setValue(rawVal);
							newas.add((AttributeInputComponent) newsic);
						} else
							newas.add((AttributeInputComponent) sic);
					} else
						newas.add((AttributeInputComponent) sic);
				}

				/*
				 * Creating MultiValuedInputComponent whose input UI is the
				 * ArrayList of AttributeInputComponent
				 */

				MultiValuedInputComponent mvedi = new MultiValuedInputComponent(
						newas, new StringInputComponent());

				mvedi.setMultiValued(true);// If it is false then there will be
											// no plus-minus button
				mvedi.setRequired(true);
				mvedi.setColumnName(colname);
				mvedi.setVisibleElements(visibleElement);
				return mvedi;
			}
		}
		return object;
	}

}
