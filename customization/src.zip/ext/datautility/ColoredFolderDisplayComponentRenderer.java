/**
 * Java file for Elecon Gears.
 */
package ext.datautility;

import wt.fc.ReferenceFactory;

import wt.folder.Folder;
import wt.util.WTException;

import com.ptc.core.components.rendering.AbstractGuiComponent;
import com.ptc.core.components.rendering.AbstractRenderer;
import com.ptc.core.components.rendering.GuiComponent;
import com.ptc.core.components.rendering.RenderingContext;
import com.ptc.core.components.rendering.RenderingException;
import com.ptc.windchill.enterprise.report.utils.ReportTaskUtil;

import java.io.PrintWriter;

/**
 * Renderer for {@link ColoredFolderDisplayComponent}.
 * 
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 * 
 * 
 */
@SuppressWarnings("rawtypes")
public class ColoredFolderDisplayComponentRenderer extends AbstractRenderer {

		/**
		 * Default comment for field serialVersionUID.
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * 
		 * @param obj
		 * @param pw
		 * @param rc
		 * @throws RenderingException
		 */
		protected void renderObject(Object obj, PrintWriter pw,
				RenderingContext rc)throws RenderingException

		{

			renderObject((ColoredFolderDisplayComponent) obj, pw, rc);

		}

		protected void renderObject(ColoredFolderDisplayComponent comp,
				PrintWriter pw, RenderingContext rc)

		throws RenderingException

		{

			write(pw, buildColorFolderDisplayComponent(comp));

		}

		
		protected String buildColorFolderDisplayComponent(
				ColoredFolderDisplayComponent dispComp)
		{

			/*<a style=font-style:normal;color:#ff4500;font-size:11px;font-family:Segoe UI,tahoma,arial,helvetica,sans-serif 
			href="http://punetrwn12805.itcinfotech.com/Windchill/"> Click Here </a>*/

			final StringBuilder htmlAsString = new StringBuilder();
			htmlAsString.append("<a style=\"font-style:normal;color:#ff4500;font-size:11px;font-family:Segoe UI,tahoma,arial,helvetica,sans-serif\" href=\"");
			final Folder folderObj = dispComp.getFolder(); 
			try {
				htmlAsString.append(ReportTaskUtil.getInfoPageURL((new ReferenceFactory().getReferenceString(folderObj))));
			} catch (WTException exception) {
				// TODO Auto-generated catch block
				exception.printStackTrace();
			}
			htmlAsString.append("\">").append(folderObj.getName()).append("</a>");
			
			return htmlAsString.toString();
		}

		/**
		 * Checking whether the given object is a valid {@link GuiComponent} or not.
		 * 
		 * @param obj given {@link AbstractGuiComponent}.
		 * 
		 * @return If the object is of type {@link ColoredFolderDisplayComponent} then yes.
		 */
		protected boolean isValidForObject(Object obj)
		{
			return (obj instanceof ColoredFolderDisplayComponent);
		}
}
