/**
 * 
 */
package ext.datautility;

import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
//ext.datautility.HTMLComponentUtility
public class HTMLComponentUtility extends DefaultDataUtility{
	
	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @return
	 * @throws WTException
	 */
	@Override
	public Object getDataValue(String componentID, Object datum, ModelContext aModelContext)
			throws WTException {
		System.out.println("Inside custom data utility :: ");
		Object obj = super.getDataValue(componentID, datum, aModelContext);
		AttributeDisplayCompositeComponent adcc = (AttributeDisplayCompositeComponent) obj;
		System.out.println("Values : ---- " + adcc.getInternalValueString());
		TextDisplayComponent localTextDisplayComponent = (TextDisplayComponent) adcc.getValueDisplayComponent();
		localTextDisplayComponent.setRichText(true);
		localTextDisplayComponent.setLongTextDisplayMode(true);
		
		return localTextDisplayComponent;
	}

}
