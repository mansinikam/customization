package ext.tablebuilder;

import wt.util.WTException;

import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.windchill.enterprise.product.mvc.builders.ProductListTableBuilder;

//@ComponentBuilder({"netmarkets.product.list"})
@OverrideComponentBuilder
public class CustomProductListTableBuilder extends ProductListTableBuilder{

	@Override
	public ComponentConfig buildComponentConfig(
			ComponentParams paramComponentParams) throws WTException {
		ComponentConfig componentConfig =super.buildComponentConfig(paramComponentParams);
		componentConfig.setLabel("My Product");
	
		return componentConfig;
	}
}
