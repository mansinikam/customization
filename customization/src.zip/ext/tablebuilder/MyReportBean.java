package ext.tablebuilder;

import wt.util.WTException;

import com.ptc.netmarkets.model.NmNamedObject;
import com.ptc.netmarkets.model.NmOid;

public class MyReportBean extends NmNamedObject {
	private String name;
	private String no;
	private String lineNumber;
	private String level;
	private String version;
	private String findnumber;
	private String state;
	private String referenceDesignator;

	MyReportBean() {
		super();
		try {
			
			super.setOid(NmOid.newNmOid(System.currentTimeMillis() + "__"
					+ Math.random()));
		} catch (WTException e) {
			e.printStackTrace();
		}
	}
	
	public String getReferenceDesignator() {
		return referenceDesignator;
	}

	public void setReferenceDesignator(String referenceDesignator) {
		this.referenceDesignator = referenceDesignator;
	}

	public String getVersion() {
		return version;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getFindnumber() {
		if (findnumber == null)
			return "";
		else
			return findnumber;
	}

	public void setFindnumber(String findnumber) {
		this.findnumber = findnumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	public String getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	
}
