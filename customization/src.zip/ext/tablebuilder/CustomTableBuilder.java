package ext.tablebuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

import wt.fc.ObjectVector;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.occurrence.Occurrence;
import wt.org.OrganizationServicesHelper;
import wt.org.WTOrganization;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.ReferenceDesignatorSet;
import wt.part.ReferenceDesignatorSetDelegateFactory;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartUsageLink;
import wt.preference.PreferenceHelper;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.VersionReference;
import wt.vc.config.LatestConfigSpec;

import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.part.structure.PartStructureNumberComparator;
import com.ptc.windchill.enterprise.util.AlphanumericStringComparisonAlgorithm;
import com.ptc.windchill.enterprise.util.PSBStringComparisonAlgorithm;
import com.ptc.windchill.enterprise.util.StringWithNumberAndTextComparisonAlgorithm;

@ComponentBuilder("ext.tablebuilder.CustomTableBuilder")
public class CustomTableBuilder extends AbstractComponentBuilder {

	@Override
	public Object buildComponentData(ComponentConfig arg0,
			ComponentParams componentParams) throws Exception {
		NmCommandBean localNmCommandBean = ((JcaComponentParams) componentParams)
				.getHelperBean().getNmCommandBean();
		@SuppressWarnings("rawtypes")
		Enumeration em = localNmCommandBean.getRequest().getParameterNames();
		String value = null;
		while (em.hasMoreElements()) {
			String[] str = localNmCommandBean.getRequest().getParameterValues(
					em.nextElement().toString());
			for (String val : str)
				if (val.contains("wt.part.WTPart")) {
					value = val;
					break;
				}
		}
		if (value == null) {
			NmOid nmoid = localNmCommandBean.getActionOid();
			WTPart part = (WTPart) nmoid.getRefObject();
			return getMultiBOMReport(part);
		} else
			return getMultiBOMReport((WTPart) ((VersionReference) (new ReferenceFactory()
					.getReference(value.substring(0, value.length() - 2))))
					.getObject());
	}

	private List<MyReportBean> getMultiBOMReport(WTPart part)
			throws WTException {

		int level = 0;
		List<MyReportBean> list = new ArrayList<MyReportBean>();
		String state = part.getLifeCycleState().getDisplay();
		MyReportBean firstBean = new MyReportBean();
		firstBean.setName(part.getName());
		firstBean.setNo(part.getNumber());
		firstBean.setState(state);
		firstBean.setFindnumber("");
		firstBean.setLineNumber("");
		firstBean.setLevel(String.valueOf(level));
		firstBean.setVersion(part.getVersionInfo().getIdentifier().getValue()
				+ "." + part.getIterationIdentifier().getValue() + "("
				+ part.getViewName() + ")");
		firstBean.setReferenceDesignator("");
		list.add(firstBean);
		getChildParts(part, list, level);
		return list;
	}

	@SuppressWarnings("unchecked")
	protected QueryResult sort(QueryResult paramQueryResult) {
		QueryResult localQueryResult = new QueryResult();

		Object[] arrayOfObject1 = new Object[paramQueryResult.size()];
		int i = 0;
		while (paramQueryResult.hasMoreElements()) {
			arrayOfObject1[i] = paramQueryResult.nextElement();
			++i;
		}

		Arrays.sort(arrayOfObject1, getComparator());
		for (int j = 0; j < i; ++j) {
			ObjectVector localObjectVector = new ObjectVector();
			Object[] arrayOfObject2 = { arrayOfObject1[j] };
			localObjectVector.addElement(arrayOfObject2);
			localQueryResult.append(localObjectVector);
		}
		return localQueryResult;
	}

	@SuppressWarnings("rawtypes")
	protected Comparator getComparator() {
		PartStructureNumberComparator localPartStructureNumberComparator = new PartStructureNumberComparator(
				getComparisonAlgorithm(), Locale.US);
		return localPartStructureNumberComparator;
	}

	private static WTContainerRef getContainer() throws WTException {
		WTPrincipalReference localWTPrincipalReference = SessionHelper.manager
				.getPrincipalReference();
		WTOrganization localWTOrganization = OrganizationServicesHelper.manager
				.getOrganization(localWTPrincipalReference.getPrincipal());
		WTContainerRef localWTContainerRef1 = WTContainerHelper.service
				.getOrgContainerRef(localWTOrganization);
		if (localWTContainerRef1 != null) {
			return localWTContainerRef1;
		}
		WTContainerRef localWTContainerRef2 = WTContainerHelper.service
				.getExchangeRef();
		return localWTContainerRef2;
	}

	@SuppressWarnings("deprecation")
	private static String getPreference() {
		String str = "SEPARATE_SECTIONS_PREF_VALUE";
		try {
			WTUser localWTUser = (WTUser) SessionHelper.manager.getPrincipal();
			WTContainerRef localWTContainerRef = getContainer();
			str = (String) PreferenceHelper.service.getValue(
					"SortingOrderForPartNumberAndNameInPSB", "WINDCHILL",
					localWTContainerRef.getReferencedContainerReadOnly(),
					localWTUser);
		} catch (WTException localWTException) {
			System.out.println(localWTException.getMessage());
		}
		return str;
	}

	protected PSBStringComparisonAlgorithm getComparisonAlgorithm() {
		Object localObject = new StringWithNumberAndTextComparisonAlgorithm();
		if (getPreference().equalsIgnoreCase("ALPHANUMERIC_PREF_VALUE"))
			localObject = new AlphanumericStringComparisonAlgorithm();
		return ((PSBStringComparisonAlgorithm) localObject);
	}

	private int getChildParts(WTPart parentPart, List<MyReportBean> list,
			int level) throws WTException {
		int level1 = level + 1;
		@SuppressWarnings("deprecation")
		QueryResult queryResult = WTPartHelper.service
				.getUsesWTPartsWithAllOccurrences(parentPart,
						new LatestConfigSpec());

		while (queryResult.hasMoreElements()) {
			WTPart part = null;
			Persistable[] persistable = (Persistable[]) queryResult
					.nextElement();

			part = (WTPart) persistable[1];
			WTPartUsageLink partLink = (WTPartUsageLink) persistable[0];
			MyReportBean bean = new MyReportBean();
			bean.setName(part.getName());
			bean.setNo(part.getNumber());
			bean.setState(part.getLifeCycleState().getDisplay());
			if (partLink.getFindNumber() == null)
				bean.setFindnumber(" ");
			else
				bean.setFindnumber(partLink.getFindNumber());

			if (partLink.getLineNumber() == null)
				bean.setLineNumber("");
			else
				bean.setLineNumber(String.valueOf(partLink.getLineNumber()
						.getValue()));

			bean.setLevel(String.valueOf(level1));
			bean.setVersion(part.getVersionInfo().getIdentifier().getValue()
					+ "." + part.getIterationIdentifier().getValue() + "("
					+ part.getViewName() + ")");
			bean.setReferenceDesignator(getReferenceDesignators(partLink));
			list.add(bean);

			getChildParts(part, list, Integer.parseInt(bean.getLevel()));
			level1 = Integer.parseInt(bean.getLevel());
		}
		return level1;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String getReferenceDesignators(WTPartUsageLink paramWTPartUsageLink)
			throws WTException {
		// System.out.println("inside " + paramWTPartUsageLink);
		if (paramWTPartUsageLink == null) {
			System.out.println("WTPartUsageLink is null");
			return "";

		}
		Vector localVector = paramWTPartUsageLink.getUsesOccurrenceVector();
		if (localVector == null) {
			return "";
		}
		int i = localVector.size();
		ArrayList localArrayList = new ArrayList(i);
		for (int j = 0; j < i; ++j) {
			// System.out.println("The class is  " + localVector.get(j));
			Occurrence occur = (Occurrence) localVector.get(j);
			String str = ((Occurrence) occur).getName();
			if (str != null)
				localArrayList.add(str);
		}
		ReferenceDesignatorSetDelegateFactory localReferenceDesignatorSetDelegateFactory = new ReferenceDesignatorSetDelegateFactory();
		Object localObject = localReferenceDesignatorSetDelegateFactory
				.get(localArrayList);
		String str = ((ReferenceDesignatorSet) localObject)
				.getConsolidatedReferenceDesignators();

		return ((String) str);
	}

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0)
			throws WTException {

		ComponentConfigFactory componentConfig = getComponentConfigFactory();
		TableConfig tableConfig = componentConfig.newTableConfig();
		tableConfig.setSelectable(false);
		tableConfig.setShowCount(true);
		tableConfig.setComponentMode(ComponentMode.VIEW);
		tableConfig.setType("wt.part.WTPart");
		tableConfig.setLabel("Custom Report Table");
		tableConfig.setId("ext.tablebuilder.CustomTableBuilder");
		tableConfig.setActionModel("part_report_toolbar_actions");

		ColumnConfig level = getComponentConfigFactory().newColumnConfig();
		level.setLabel("Level");
		level.setId("level");
		level.setSortable(false);
		level.setDefaultSort(false);
		tableConfig.addComponent(level);

		ColumnConfig name = getComponentConfigFactory().newColumnConfig();
		name.setLabel("Name");
		name.setId("name");
		name.setSortable(false);
		name.setDefaultSort(false);
		// name.setDataUtilityId("namedatautil");
		tableConfig.addComponent(name);

		ColumnConfig no = getComponentConfigFactory().newColumnConfig();
		no.setLabel("Number");
		no.setId("no");
		no.setSortable(false);
		no.setDefaultSort(false);
		tableConfig.addComponent(no);

		ColumnConfig version = getComponentConfigFactory().newColumnConfig();
		version.setLabel("Version");
		version.setId("version");
		version.setSortable(false);
		version.setDefaultSort(false);
		tableConfig.addComponent(version);

		ColumnConfig state = getComponentConfigFactory().newColumnConfig();
		state.setLabel("State");
		state.setId("state");
		state.setSortable(false);
		state.setDefaultSort(false);
		// state.setDataUtilityId("myLifCycleState");
		tableConfig.addComponent(state);

		ColumnConfig lineNumber = getComponentConfigFactory().newColumnConfig();
		lineNumber.setLabel("Line Number");
		lineNumber.setId("lineNumber");
		lineNumber.setSortable(false);
		lineNumber.setDefaultSort(false);
		tableConfig.addComponent(lineNumber);

		ColumnConfig number = getComponentConfigFactory().newColumnConfig();
		number.setLabel("Find Number");
		number.setId("findnumber");
		number.setSortable(false);
		number.setDefaultSort(false);
		tableConfig.addComponent(number);

		ColumnConfig referenceDesignator = getComponentConfigFactory()
				.newColumnConfig();
		referenceDesignator.setLabel("Reference Designator");
		referenceDesignator.setId("referenceDesignator");
		referenceDesignator.setSortable(false);
		referenceDesignator.setDefaultSort(false);
		tableConfig.addComponent(referenceDesignator);

		return tableConfig;
	}

}

/*
 * The goal of this example is to show how to create a table contains part data
 * using your own bean object. Even for the OOTB report they are using their own
 * bean named �Report Row�, �PartReportCollectorBean� etc.
 * 
 * In the above code some lines are commented. After writing the DataUtility
 * (described below) uncomment those line.
 * 
 * To apply All the data utilities used in this example first you have to
 * register them.
 * 
 * The class is not written as per the sonar guide line.
 */

