package ext.generic.projectbaseline.modelling;

//ext.generic.projectbaseline.modelling.ProjectToProjectPlanBaselineLink
import java.io.Externalizable;

import wt.fc.ObjectToObjectLink;
import wt.projmgmt.admin.Project2;
import wt.util.WTException;

import com.ptc.windchill.annotations.metadata.GenAsBinaryLink;
import com.ptc.windchill.annotations.metadata.GeneratedRole;
import com.ptc.windchill.annotations.metadata.OracleTableSize;
import com.ptc.windchill.annotations.metadata.TableProperties;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
@GenAsBinaryLink(superClass = ObjectToObjectLink.class, interfaces = { Externalizable.class },

roleA = @GeneratedRole(name = "Project", type = Project2.class),

roleB = @GeneratedRole(name = "ProjectBaseLine", type = ProjectPlanBaseline.class),

tableProperties = @TableProperties(tableName = "ProjectToPlanBaselineLink", oracleTableSize = OracleTableSize.LARGE))
public class ProjectToProjectPlanBaselineLink extends
		_ProjectToProjectPlanBaselineLink {

	/**
	 * Variable to store the value of serialVersionUID.
	 */
	static final long serialVersionUID = 1;

	/**
	 * Constructor method for {@link ProjectToProjectPlanBaselineLink}.
	 * 
	 * @param project
	 *            {@link Project2} object.
	 * 
	 * @param baseline
	 *            {@link ProjectPlanBaseline} object.
	 * 
	 * @return the link.
	 * 
	 * @throws WTException
	 *             throws {@link WTException}.
	 */
	public static ProjectToProjectPlanBaselineLink newProjectToProjectPlanBaselineLink(
			Project2 project, ProjectPlanBaseline baseline) throws WTException {
		// ##begin newProjectToBaselineLink%newProjectToBaselineLinkf.body
		// preserve=no

		ProjectToProjectPlanBaselineLink instance = new ProjectToProjectPlanBaselineLink();
		instance.initialize(project, baseline);
		return instance;
		// ##end newProjectToBaselineLink%newProjectToBaselineLinkf.body
	}

}
