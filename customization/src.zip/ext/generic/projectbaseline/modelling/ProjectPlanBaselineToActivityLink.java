package ext.generic.projectbaseline.modelling;

import java.io.Externalizable;

import wt.fc.ObjectToObjectLink;
import wt.util.WTException;

import com.ptc.windchill.annotations.metadata.GenAsBinaryLink;
import com.ptc.windchill.annotations.metadata.GeneratedRole;
import com.ptc.windchill.annotations.metadata.OracleTableSize;
import com.ptc.windchill.annotations.metadata.TableProperties;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
@GenAsBinaryLink(superClass = ObjectToObjectLink.class, interfaces = { Externalizable.class },

roleA = @GeneratedRole(name = "ProjectBaseline", type = ProjectPlanBaseline.class),

roleB = @GeneratedRole(name = "ProjectBaseLineActivity", type = ProjectPlanBaselineActivity.class),

tableProperties = @TableProperties(tableName = "PlanBaselineToActivityLink", oracleTableSize = OracleTableSize.LARGE))
public class ProjectPlanBaselineToActivityLink extends
		_ProjectPlanBaselineToActivityLink {

	/**
	 * Final Long variable.
	 */
	static final long serialVersionUID = 1;

	/**
	 * Constructor method to create {@link ProjectPlanBaselineToActivityLink}.
	 * 
	 * @param projectbaseline
	 *            {@link ProjectPlanBaseline} object.
	 * 
	 * @param projectbaselineactivity
	 *            {@link ProjectPlanBaselineActivity}.
	 * 
	 * @return the link.
	 * 
	 * @throws WTException
	 *             throws {@link WTException}.
	 */
	public static ProjectPlanBaselineToActivityLink newProjectPlanBaselineToActivityLink(
			ProjectPlanBaseline projectbaseline,
			ProjectPlanBaselineActivity projectbaselineactivity)
			throws WTException {
		// ##begin newBaselineToActivityLink%newBaselineToActivityLinkf.body
		// preserve=no

		ProjectPlanBaselineToActivityLink instance = new ProjectPlanBaselineToActivityLink();
		instance.initialize(projectbaseline, projectbaselineactivity);
		return instance;
		// ##end newBaselineToActivityLink%newBaselineToActivityLinkf.body
	}

}
