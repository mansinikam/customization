package ext.generic.projectbaseline.modelling;

import java.io.Externalizable;

import wt.fc.ObjectReference;
import wt.fc.WTObject;
import wt.util.WTException;

import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.IconProperties;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
@GenAsPersistable(superClass = WTObject.class, interfaces = {
		Externalizable.class, ProjectPlanBaselinePlannable.class }, properties = {
		@GeneratedProperty(name = "workComplete", type = double.class),

		@GeneratedProperty(name = "planActivityReference", type = ObjectReference.class),

		@GeneratedProperty(name = "milestone", type = boolean.class),

		@GeneratedProperty(name = "summary", type = boolean.class),

		@GeneratedProperty(name = "activityResource", type = String.class),

		@GeneratedProperty(name = "parentObjRef", type = ObjectReference.class) }, iconProperties = @IconProperties(standardIcon = "netmarkets/images/activity.png", openIcon = "netmarkets/images/activity.png"))
public class ProjectPlanBaselineActivity extends _ProjectPlanBaselineActivity {
	/**
	 * Final Long variable.
	 */
	static final long serialVersionUID = 1;

	/**
	 * Constructor for {@link ProjectPlanBaselineActivity}.
	 * 
	 * @return {@link ProjectPlanBaselineActivity}.
	 * 
	 * @throws WTException
	 *             throws {@link WTException}.
	 */
	public static ProjectPlanBaselineActivity newProjectPlanBaselineActivity()
			throws WTException {
		ProjectPlanBaselineActivity instance = new ProjectPlanBaselineActivity();
		/*
		 * Initialize with blank value.
		 */
		instance.initialize();
		/*
		 * Static method to create the object.
		 */
		return instance;
	}

}
