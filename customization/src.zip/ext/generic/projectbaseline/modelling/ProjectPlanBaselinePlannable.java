package ext.generic.projectbaseline.modelling;

import java.sql.Timestamp;

import wt.org.WTPrincipalReference;

import com.ptc.projectmanagement.plan.Duration;
import com.ptc.windchill.annotations.metadata.ColumnProperties;
import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;

//ext.generic.projectbaseline.modelling.ProjectPlanBaselinePlannable
/**
 * Interface to hold the common attribute of ProjectPlanBaseline and
 * ProjectPlanBaselineActivity.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 * 
 */
@GenAsPersistable(properties = {
		@GeneratedProperty(name = "name", type = String.class, columnProperties = @ColumnProperties(index = true), constraints = @PropertyConstraints(required = true, upperLimit = 255)),

		@GeneratedProperty(name = "duration", type = Duration.class),

		@GeneratedProperty(name = "estimatedStartDate", type = Timestamp.class),

		@GeneratedProperty(name = "actualStartDate", type = Timestamp.class),

		@GeneratedProperty(name = "estimatedFinishDate", type = Timestamp.class),

		@GeneratedProperty(name = "actualFinishDate", type = Timestamp.class),

		@GeneratedProperty(name = "owner", type = WTPrincipalReference.class),

		@GeneratedProperty(name = "lineNumber", type = int.class),

		@GeneratedProperty(name = "cost", type = double.class),

		@GeneratedProperty(name = "rolledUpCost", type = double.class),

		@GeneratedProperty(name = "fixedCost", type = double.class),

		@GeneratedProperty(name = "dummy1", type = String.class),

		@GeneratedProperty(name = "dummy2", type = String.class) })
public interface ProjectPlanBaselinePlannable extends
		_ProjectPlanBaselinePlannable {
	/*
	 * Interface holding all the common attributes of both the object.
	 * 
	 * Two dummy attributes are also included for future purpose.
	 */

}
