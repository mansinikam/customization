package ext.generic.projectbaseline.modelling;

import java.io.Externalizable;

import wt.fc.WTObject;
import wt.org.WTPrincipalReference;
import wt.util.WTException;

import com.ptc.windchill.annotations.metadata.ColumnProperties;
import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.IconProperties;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;

//ext.generic.projectbaseline.modelling.ProjectPlanBaseline
/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
@GenAsPersistable(superClass = WTObject.class, interfaces = {
		Externalizable.class, ProjectPlanBaselinePlannable.class }, properties = {

		@GeneratedProperty(name = "baseplanNumber", type = String.class, columnProperties = @ColumnProperties(index = true), constraints = @PropertyConstraints(upperLimit = 60)),

		@GeneratedProperty(name = "description", type = String.class, constraints = @PropertyConstraints(upperLimit = 4000)),

		@GeneratedProperty(name = "creator", type = WTPrincipalReference.class) },

iconProperties = @IconProperties(standardIcon = "netmarkets/images/baseline.gif", openIcon = "netmarkets/images/baseline.gif"))
public class ProjectPlanBaseline extends _ProjectPlanBaseline {
	/**
	 * Final Long variable.
	 */
	static final long serialVersionUID = 1;

	/**
	 * Static method to create {@link ProjectPlanBaseline}.
	 * 
	 * @return object of {@link ProjectPlanBaseline}.
	 * 
	 * @throws WTException
	 *             {@link WTException}.
	 */
	public static ProjectPlanBaseline newProjectPlanBaseline()
			throws WTException {
		ProjectPlanBaseline instance = new ProjectPlanBaseline();
		instance.initialize();
		return instance;

	}
}
