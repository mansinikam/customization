package ext.rule;
import org.apache.log4j.Logger;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.pds.StatementSpec;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.rule.algorithm.RuleAlgorithm;
import wt.util.WTException;

/**
 * Class getting sequence will generate sequence number for WTDocument.
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * @version 'true' 1.0
 */
public class GettingSequence implements RuleAlgorithm {
	/**
	 * Private variable for logger
	 */
	private static final Logger LOG = LogR.getLogger(GettingSequence.class
			.getName());
	/**
	 * This method is an overidden method of RuleAlgorithm interface.
	 * @param args
	 *            The Object array where user's input will be stored if any
	 * @param containerRef
	 *            The WTContainerReference in which the WTObject will go. 
	 * @return Return the sequence
	 * @exception WTException
	 *                throws {@link WTException}
	 */
	public Object calculate(Object[] args, WTContainerRef containerRef) throws WTException {
		final WTContainer cont = containerRef.getReferencedContainer();
		if (cont instanceof Project2) {
			final String number = ((Project2) cont).getProjectNumber();
			LOG.debug("number " + number);
			
			final QuerySpec queryspec = new QuerySpec(WTDocument.class);
			final int contIndex = queryspec.appendClassList(Project2.class,
					false);
			
			final SearchCondition searchCondition = new SearchCondition(
					WTDocument.class, "containerReference.key.id",
					Project2.class, wt.util.WTAttributeNameIfc.ID_NAME);
			
			
			queryspec.appendWhere(searchCondition, new int[] { 0, contIndex });
			queryspec.appendAnd();
			SearchCondition scSWPart = new SearchCondition(Project2.class,
					"containerInfo.name", SearchCondition.EQUAL,
					((Project2) cont).getName(), true);
			queryspec.appendWhere(scSWPart, new int[] { contIndex });
			final QueryResult qr = PersistenceHelper.manager
					.find((StatementSpec) queryspec);
			LOG.debug("size " + qr.size());
			return (String.format("%04d",( qr.size() + 1)) + "-" + number);
		}
		return null;
	}
}
