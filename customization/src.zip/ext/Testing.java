/**
 * Custom class file.
 * 
 * @author 'true' 12805
 * 
 * @version 'true' 1.0
 *
 */
package ext;

/**
 * @author 12805
 *
 */
public class Testing {

}
