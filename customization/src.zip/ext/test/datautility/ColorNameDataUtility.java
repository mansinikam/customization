package ext.test.datautility;

import java.sql.Timestamp;
import java.util.Date;

import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.NameDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.projectmanagement.plan.PlanActivity;

/**
 * ColorNameDataUtility will highlight any PlanActivity which is critical or the
 * due date is over when user will view any project's plan.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 */
public class ColorNameDataUtility extends NameDataUtility {
	@Override
	public Object getDataValue(String paramString, Object datum,
			ModelContext paramModelContext) throws WTException {
		Object obj = super.getDataValue(paramString, datum,
				paramModelContext);
		if (obj instanceof AttributeDisplayCompositeComponent
				&& datum instanceof PlanActivity) {
			AttributeDisplayCompositeComponent adcc = (AttributeDisplayCompositeComponent) obj;
			TextDisplayComponent tdc = (TextDisplayComponent) adcc
					.getValueDisplayComponent();
			PlanActivity planActivity = (PlanActivity) datum;
			if (planActivity.isCritical()
					|| isDueDatePassed(planActivity.getDeadline(),
							planActivity.getPercentWorkComplete())) {
				tdc.addStyleClass("overdueDate");
				/*
				 * overdueDate is name of a OOTB style class which is written
				 * inside xtheme-windchill.css
				 */
				tdc.setDivClass("overdueDate");
				/*
				 * The path of the css file
				 * <WINDCHILL_HOME>\codebase\netmarkets\
				 * themes\windchill\xtheme-windchill.css
				 */
				return tdc;
			} else {
				return obj;
			}
		}
		return obj;
	}

	private boolean isDueDatePassed(Timestamp paramTimestamp, double paramDouble) {
		Date localDate = new Date();
		if (paramTimestamp != null) {
			return ((paramTimestamp.before(localDate)) && (paramDouble < 100.0D));
		}
		return false;
	}
}
