package ext.test.datautility;

import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.RadioButton;
import com.ptc.core.components.rendering.guicomponents.RadioButtonGroup;
import com.ptc.core.ui.resources.ComponentMode;

public class RadioButtonDataUtility extends DefaultDataUtility {
	public Object getDataValue(String componentId, Object datum,
			ModelContext modelContext) throws WTException {
		if (modelContext.getDescriptorMode().equals(ComponentMode.CREATE)) {

			System.out.println("Inside custom data utility2");
			RadioButtonGroup radioButtonGroup = new RadioButtonGroup();
			RadioButton localRadioButton1 = new RadioButton();
			/* 167 */localRadioButton1.setLabel("Internal Fixed Price");
			/* 168 */localRadioButton1.setRenderLabel(true);
			localRadioButton1.setValue("Internal Fixed Price");
			/* 169 */// localRadioButton1.setNameQualifier("Option_One");
			/* 170 */localRadioButton1.setColumnName(AttributeDataUtilityHelper
					.getColumnName(componentId, datum, modelContext));
			/* 171 */localRadioButton1.setId(componentId);
			/* 172 */((RadioButtonGroup) radioButtonGroup)
					.addButton(localRadioButton1);
			/*     */
			/* 174 */RadioButton localRadioButton2 = new RadioButton();
			/* 175 */localRadioButton2.setLabel("Internal Time and Resource");
			localRadioButton2.setValue("Internal Time and Resource");
			/* 176 */localRadioButton2.setRenderLabel(true);
			/* 177 */// localRadioButton2.setNameQualifier("Option_Two");
			/* 178 */localRadioButton2.setColumnName(AttributeDataUtilityHelper
					.getColumnName(componentId, datum, modelContext));
			/* 179 */localRadioButton2.setId(componentId);
			/* 180 */((RadioButtonGroup) radioButtonGroup)
					.addButton(localRadioButton2);
			/*     */
			/* 182 */RadioButton localRadioButton3 = new RadioButton();
			/* 183 */localRadioButton3.setLabel("External Time and Resource");
			localRadioButton3.setValue("External Time and Resource");
			/* 184 */localRadioButton3.setRenderLabel(true);
			/* 185 */// localRadioButton3.setNameQualifier("Option_Three");
			/* 186 */localRadioButton3.setColumnName(AttributeDataUtilityHelper
					.getColumnName(componentId, datum, modelContext));
			/* 187 */localRadioButton3.setId(componentId);
			/* 188 */((RadioButtonGroup) radioButtonGroup)
					.addButton(localRadioButton3);
			
			RadioButton localRadioButton4 = new RadioButton();
			/* 183 */localRadioButton4.setLabel("External Fixed Price");
			localRadioButton4.setValue("External Fixed Price");
			/* 184 */localRadioButton4.setRenderLabel(true);
			/* 185 */// localRadioButton3.setNameQualifier("Option_Three");
			/* 186 */localRadioButton4.setColumnName(AttributeDataUtilityHelper
					.getColumnName(componentId, datum, modelContext));
			/* 187 */localRadioButton4.setId(componentId);
			/* 188 */((RadioButtonGroup) radioButtonGroup)
					.addButton(localRadioButton4);
			radioButtonGroup.setRenderLabelOnRight(false);
			radioButtonGroup.setMultiValued(false);
			/*
			 * If you want multiple value to be selected by user then set the
			 * value true.
			 */
			radioButtonGroup.setColumnName(AttributeDataUtilityHelper
					.getColumnName(componentId, datum, modelContext));
			radioButtonGroup.setId(componentId);
			return radioButtonGroup;

		}

		return super.getDataValue(componentId, datum, modelContext);
	}
}
