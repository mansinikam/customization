package ext.test.validator;

import java.util.Locale;

import wt.fc.Persistable;
import wt.fc.WTReference;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.part.WTPart;

import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationResult;
import com.ptc.core.ui.validation.UIValidationResultSet;
import com.ptc.core.ui.validation.UIValidationStatus;

/**
 * Validator to validate an action. Only enable the action in PDMLinkProduct.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 */
public class SetStateValidator extends DefaultUIComponentValidator {

	/**
	 * Overidden method of "DefaultUIComponentValidator".
	 * 
	 * @param validationKey
	 *            The String identifying the action or component being
	 *            validated.
	 * @param validationCriteria
	 *            Object holding information required to per form validation
	 *            tasks.
	 * @param locale
	 *            The user's Locale. If a null value is passed in, the session
	 *            locale will be used.
	 * @return UIValidationResultSet
	 */
	public UIValidationResultSet performFullPreValidation(
			UIValidationKey validationKey,
			UIValidationCriteria validationCriteria, Locale locale) {
		// Creates UIValidationResultSet
		UIValidationResultSet resultSet = UIValidationResultSet.newInstance();
		Persistable localPersistable = null;
		if (validationCriteria != null) {
			WTReference localWTReference = validationCriteria
					.getContextObject();
			localPersistable = localWTReference.getObject();
		}
		if ((localPersistable != null) && (localPersistable instanceof WTPart)) {
			State localState = ((LifeCycleManaged) localPersistable)
					.getLifeCycleState();
			if ((State.toState("INWORK").equals(localState))) {
				resultSet.addResult(UIValidationResult.newInstance(
						validationKey, UIValidationStatus.DISABLED));
			} else {
				resultSet.addResult(UIValidationResult.newInstance(
						validationKey, UIValidationStatus.ENABLED));
			}
		}
		return resultSet;
	}
}
