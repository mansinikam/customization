package ext.test.validator;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.util.WTException;

import com.ptc.core.ui.resources.FeedbackType;

import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationFeedbackMsg;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationResult;
import com.ptc.core.ui.validation.UIValidationResultSet;
import com.ptc.core.ui.validation.UIValidationStatus;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.windchill.enterprise.requirement.validators.EditMultiObjectsActionValidator;

/**
 * Class to validate the form data submitted from the EditMultiple action.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 * 
 */
public class SourceValueValidator extends EditMultiObjectsActionValidator {
	/**
	 * Private variable for logger.
	 */
	private static final Logger LOG = LogR.getLogger(SourceValueValidator.class
			.getName());

	/**
	 * Overridden method of
	 * {@link com.ptc.core.ui.validation.DefaultUIComponentValidator}.
	 * 
	 * @param paramUIValidationKey
	 *            key for validation
	 * 
	 * @param paramUIValidationCriteria
	 *            criteria for validation
	 * 
	 * @param paramLocale
	 *            {@link Locale} typically it's Locale.US
	 * 
	 * @exception WTException
	 *                throws {@link WTException}
	 * 
	 * @return resultSet the object of {@link UIValidationResultSet}
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public UIValidationResult validateFormSubmission(
			UIValidationKey paramUIValidationKey,
			UIValidationCriteria paramUIValidationCriteria, Locale paramLocale)
			throws WTException {
		/* Calling the super class method to validate OOTB constraints */
		UIValidationResult resultSet = super.validateFormSubmission(
				paramUIValidationKey, paramUIValidationCriteria, paramLocale);
		/*
		 * Fetching the Persistable objects which intended to be modified.
		 */
		List targetObjects = paramUIValidationCriteria.getSelectedOidForPopup();
		/*
		 * Iterator to traversing the List.
		 */
		Iterator targetRefIterator = targetObjects.iterator();
		WTPart part = null;
		LOG.debug("Number of selected target objects " + targetObjects.size());
		Persistable per = null;
		while (targetRefIterator.hasNext()) {
			/*
			 * Fetching the Persistable obejct one by one.
			 */
			per = (Persistable) (((NmOid) targetRefIterator.next())
					.getRefObject());
			LOG.debug("The persistable object " + per);
			/*
			 * Checking whether the Persistable object is WTPart or not.
			 */
			if (per instanceof WTPart) {
				part = (WTPart) per;
				try {
					/*
					 * If the Persistable objext is WTPart then validating the
					 * value of ItemGroup against Source value.
					 */
					if (!(isValueValid(part, paramUIValidationCriteria))) {
						/*
						 * Denying the form submission if the value is not
						 * valid.
						 */
						LOG.debug("Denying the form submission");
						resultSet.setStatus(UIValidationStatus.DENIED);
						LOG.debug("Adding feedback message");
						resultSet.addFeedbackMsg(UIValidationFeedbackMsg
								.newInstance(

										"Check the value of "
												.concat(((WTPart) per)
														.getNumber())
												.concat(" , ")
												.concat(((WTPart) per)
														.getName()).toString(),
										FeedbackType.ERROR));
					}
				} catch (IOException e) {
					LOG.error(e);
					e.printStackTrace();
				}
			}
		}
		/* Returning the ResultSet after modification if necessary */
		return resultSet;
	}

	/**
	 * Method to check whether valid value is selected or not.
	 * 
	 * @param part
	 *            {@link WTPart} which value need to be checked.
	 * 
	 * @param paramuiUiValidationCriteria
	 *            {@link UIValidationCriteria} based on which the validation
	 *            need to be checked.
	 * 
	 * @return boolean based on the validation will happen
	 * 
	 * @throws WTException
	 *             new {@link WTException}
	 * 
	 * @throws IOException
	 *             new {@link IOException}
	 */
	private boolean isValueValid(WTPart part,
			UIValidationCriteria paramuiUiValidationCriteria)
			throws WTException, IOException {
		/*
		 * Extracting the Version Reference from the WTPart.
		 */
		final String makeValues = "010000-Fabricated Item,020000-Machined Part,030000-Machined Fabrication,040000-Assembly/Sub-assembly,050000-Prepared Material,160000-Bearing,170000-Coupling";
		final String buyValues = "210375-Lubricant & Industrial Oil,210525-Paints & Varnishe,210650-Welding Electrode";
		String versionIdentifier = new StringBuffer("VR:wt.part.WTPart:")
				.append(String.valueOf(part.getBranchIdentifier())).toString();
		LOG.debug(part.getName() + "   " + part.getNumber());

		String[] values = getValue(versionIdentifier, new String[] {
				"ItemGroup", "source" }, paramuiUiValidationCriteria);
		LOG.debug("size of array" + values.length);
		/*
		 * Fetching the legal values from the Property file.
		 */
		if (values[0] != null && values[1] != null) {

			String legalValues = null;
			if (values[1].contains("Buy")) {
				legalValues = buyValues;
			} else {
				legalValues = makeValues;
			}
			if (legalValues.contains(values[0])) {
				/*
				 * Return true if the value is valid.
				 */
				return true;
			}
		} else {
			/*
			 * If the value is null that means user didn't change them.
			 */
			return true;
		}
		return false;
	}

	/**
	 * Getting the value of ItemGroup and Source for one part.
	 * 
	 * @param vr
	 *            {@link String} contains VR.
	 * 
	 * @param attrName
	 *            String array of Attributes.
	 * 
	 * @param validationCriteria
	 *            Validation criteria.
	 * 
	 * @return the String array with the value.
	 */
	private String[] getValue(String vr, String[] attrName,
			UIValidationCriteria validationCriteria) {
		String[] value = new String[2];
		/*
		 * All the old combo box name will have old at the end.
		 */
		final String old = "old";
		Map<String, List<String>> map = validationCriteria.getComboBox();
		Iterator<String> iter = map.keySet().iterator();
		/*
		 * Traversing through the map one by one.
		 */
		while (iter.hasNext()) {
			String val = iter.next();
			LOG.debug("The value of the Key" + val);
			/*
			 * Fetching the value of ItemGroup.
			 */
			if (val.contains(attrName[0]) && val.contains(vr)
					&& !(val.endsWith(old))) {
				List<String> array = map.get(val);
				value[0] = array.get(0);
				LOG.debug("Value :-" + value[0]);
			} else if (val.contains(attrName[1]) && val.contains(vr)
					&& !(val.endsWith(old))) {
				/*
				 * Fetching the value of Source.
				 */
				value[1] = ((List<String>) map.get(val)).get(0);
				LOG.debug("Value :- " + value[1]);
			}
		}
		/*
		 * Returning the value of Item Group and the Source.
		 */
		return value;
	}
}
