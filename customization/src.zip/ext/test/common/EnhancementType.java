package ext.test.common;

import java.util.Hashtable;
import java.util.Locale;

import wt.fc.EnumeratedType;

import com.ptc.windchill.annotations.metadata.GenAsEnumeratedType;
import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.SupportedAPI;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
@GenAsEnumeratedType(supportedAPI = SupportedAPI.PUBLIC)
@GenAsPersistable(superClass = EnumeratedType.class)
public class EnhancementType extends EnumeratedType {
	private static final long serialVersionUID = -864855612543696562L;
	public static final EnhancementType CAPACITY;
	public static final EnhancementType OTHERS;
	private static final EnumeratedType[] valueSet;
	private static Hashtable<Locale, EnumeratedType[]> localeSets;

	public static EnhancementType toEnhancementType(String key) {
		try {
			return (EnhancementType) toEnumeratedType(key, valueSet);
		} catch (Exception e) {
			return null;
		}
	}

	public static EnhancementType newEnhancementType(int i)
			throws IllegalAccessException {
		EnhancementType.validateFriendship(i);
		return new EnhancementType();
	}

	public static EnhancementType getEnhancementTypeDefault() {
		return (EnhancementType) EnhancementType
				.defaultEnumeratedType(valueSet);
	}

	public static EnhancementType[] getEnhancementTypeSet() {
		EnhancementType apriority[] = new EnhancementType[valueSet.length];
		System.arraycopy(valueSet, 0, apriority, 0, valueSet.length);
		return apriority;
	}

	@Override
	public EnumeratedType[] getValueSet() {
		return ((EnumeratedType[]) (EnhancementType.getEnhancementTypeSet()));
	}

	@Override
	protected EnumeratedType[] valueSet() {
		return valueSet;
	}

	@Override
	protected EnumeratedType[] getLocaleSet(Locale locale) {
		EnumeratedType aenumeratedtype[] = null;
		if (localeSets == null) {
			localeSets = new Hashtable<Locale, EnumeratedType[]>();
		} else {
			aenumeratedtype = (EnumeratedType[]) (EnumeratedType[]) localeSets
					.get(locale);
		}
		if (aenumeratedtype == null) {
			try {
				aenumeratedtype = EnhancementType.initializeLocaleSet(locale);
			} catch (Throwable throwable) {
			}
			localeSets.put(locale, aenumeratedtype);
		}
		return aenumeratedtype;
	}

	private static EnumeratedType[] initializeLocaleSet(Locale locale)
			throws Throwable {
		Class<?> aclass[] = { Integer.TYPE };
		return EnhancementType
				.instantiateSet((EnhancementType.class).getMethod(
						"newEnhancementType", aclass),
						EnhancementType.class.getName() + "RB", locale);
	}

	static {
		try {
			valueSet = EnhancementType.initializeLocaleSet(null);
			CAPACITY = EnhancementType.toEnhancementType("Capacity");
			OTHERS = EnhancementType.toEnhancementType("Others");
		} catch (Throwable t) {
			throw new ExceptionInInitializerError(t);
		}
	}
}
