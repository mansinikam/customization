package ext.test.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

/**
 * The resource bundle file for the custom actions.
 * 
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1.0
 * 
 */
@RBUUID("ext.test.resource.CustomActionResource")
public class CustomActionResource extends WTListResourceBundle {
	/*
	 * Any custom Resource Bundle file's name must ends with either "Resource"
	 * or "RB"(In capital) else the process will not work
	 */
	
	/**
	 * 
	 */
	@RBEntry("Select Type")
	public static final String SELECT_TYPE_DESCRIPTION="itc.selectType.description";
	
	/** Create Object title **/
	@RBEntry("Create Object")
	public static final String CREATEOBJECT_TITLE = "itc.createObject.title";

	/** Create Object tool tip **/
	@RBEntry("Create Object")
	public static final String CREATEOBJECT_TOOLTIP = "itc.createObject.tooltip";

	/** Create Object description **/
	@RBEntry("Create Object")
	public static final String CREATEOBJECT_DESCRIPTION = "itc.createObject.description";
	/*
	 * The entry format must follow one simple rule
	 * <action_type>.<action_name>.title/tooltip/description/icon etc.
	 */
	/** Select Object title **/
	@RBEntry("Select Object")
	public static final String SELECTOBJECT_TITLE = "itc.selectObject.title";

	/** Select Object tool tip **/
	@RBEntry("Select Object")
	public static final String SELECTOBJECT_TOOLTIP = "itc.selectObject.tooltip";

	/** Select Object description **/
	@RBEntry("Select Object")
	public static final String SELECTOBJECT_DESCRIPTION = "itc.selectObject.description";

	/** Set Attribute title **/
	@RBEntry("Set Part Attribute")
	public static final String SETATTRIBUTEWIZSTEP_TITLE = "itc.setAttributeWizStep.title";

	/** Set Attribute tool tip **/
	@RBEntry("Set Part Attribute")
	public static final String SETATTRIBUTEWIZSTEP_TOOLTIP = "itc.setAttributeWizStep.tooltip";

	/** Set Attribute description **/
	@RBEntry("Set Part Attribute")
	public static final String SETATTRIBUTEWIZSTEP_DESCRIPTION = "itc.setAttributeWizStep.description";

	/** Set Attribute title **/
	@RBEntry("Set Attribute")
	public static final String SETATTRIBUTE_TITLE = "itc.setAttribute.title";

	/** Set Attribute tool tip **/
	@RBEntry("Set Attribute")
	public static final String SETATTRIBUTE_TOOLTIP = "itc.setAttribute.tooltip";

	/** Set Attribute description **/
	@RBEntry("Set Attribute")
	public static final String SETATTRIBUTE_DESCRIPTION = "itc.setAttribute.description";

	/** More URL Info for Create Object **/
	@RBEntry("width=1000,height=1000")
	// Provide the height and width of the pop-up window
	@RBPseudo(false)
	public static final String CREATEOBJECT_MOREURLINFO = "itc.createObject.moreurlinfo";
	/** Create Object Icon **/
	@RBEntry("create_restore.gif")
	// The image is in netmarkets/images
	@RBPseudo(false)
	public static final String CREATEOBJECT_ICON = "itc.createObject.icon";

	/** Set Attribute title **/
	@RBEntry("Select Usage Link")
	public static final String SELECTUSAGE_TITLE = "itc.selectUsage.title";

	/** Set Attribute tool tip **/
	@RBEntry("Select Usage Link")
	public static final String SELECTUSAGE_TOOLTIP = "itc.selectUsage.tooltip";

	/** Set Attribute description **/
	@RBEntry("Select Usage Link")
	public static final String SELECTUSAGE_DESCRIPTION = "itc.selectUsage.description";

	/** Set Attribute title **/
	@RBEntry("split Usage Link")
	public static final String SPLIT_TITLE = "psb.splitGWT.title";

	/** Set Attribute tool tip **/
	@RBEntry("split Usage Link")
	public static final String SPLIT_TOOLTIP = "psb.splitGWT.tooltip";

	/** Set Attribute description **/
	@RBEntry("split Usage Link")
	public static final String SPLIT_DESCRIPTION = "psb.splitGWT.description";

	/** Create Object Icon **/
	@RBEntry("create_restore.gif")
	// The image is in netmarkets/images
	@RBPseudo(false)
	public static final String SPLIT_ICON = "psb.splitGWT.icon";

	/** Set Attribute title **/
	@RBEntry("Split Usage Link")
	public static final String SPLITWIZARD_TITLE = "itc.splitWizard.title";

	/** Set Attribute tool tip **/
	@RBEntry("Split Usage Link")
	public static final String SPLITWIZARD_TOOLTIP = "itc.splitWizard.tooltip";

	/** Set Attribute description **/
	@RBEntry("Split Usage Link")
	public static final String SPLITWIZARD_DESCRIPTION = "itc.splitWizard.description";

	/** Set Attribute title **/
	@RBEntry("Split Usage Link Step")
	public static final String SPLITWIZARDSTEP_TITLE = "itc.splitWizardStep.title";

	/** Set Attribute tool tip **/
	@RBEntry("Split Usage Link Step")
	public static final String SPLITWIZARDSTEP_TOOLTIP = "itc.splitWizardStep.tooltip";

	/** Set Attribute description **/
	@RBEntry("Split Usage Link Step")
	public static final String SPLITWIZARDSTEP_DESCRIPTION = "itc.splitWizardStep.description";

	/** Custom Table title **/
	@RBEntry("Custom Table")
	public static final String CUSTOM_TABLE_TITLE = "itc.customtable.title";

	/** Custom Table tool tip **/
	@RBEntry("Custom Table")
	public static final String CUSTOM_TABLE_TOOLTIP = "itc.customtable.tooltip";

	/** Custom Table description **/
	@RBEntry("Custom Table")
	public static final String CUSTOM_TABLE_DESCRIPTION = "itc.customtable.description";

	/** Create Object Icon **/
	@RBEntry("dataMonitor.png")
	// The image is in netmarkets/images
	@RBPseudo(false)
	public static final String CUSTOM_TABLE_ICON = "itc.customtable.icon";
	
	
	/** Custom Table title **/
	@RBEntry("Custom Table")
	public static final String CUSTOMIE_TABLE_TITLE = "itc.customtableie.title";

	/** Custom Table tool tip **/
	@RBEntry("Custom Table")
	public static final String CUSTOMIE_TABLE_TOOLTIP = "itc.customtableie.tooltip";

	/** Custom Table description **/
	@RBEntry("Custom Table")
	public static final String CUSTOMIE_TABLE_DESCRIPTION = "itc.customtableie.description";

	/** Custom Table Icon IE **/
	@RBEntry("address.png")
	// The image is in netmarkets/images
	@RBPseudo(false)
	public static final String CUSTOMIE_TABLE_ICON = "itc.customtableie.icon";
	
	

	/** Container List Table title **/
	@RBEntry("Container List Table")
	public static final String CONTAINER_LIST_TITLE = "itc.containerlist.title";

	/** Container List Table tool tip **/
	@RBEntry("Container List Table")
	public static final String CONTAINER_LIST_TOOLTIP = "itc.containerlist.tooltip";

	/** Container List Table description **/
	@RBEntry("Container List Table")
	public static final String CONTAINER_LIST_DESCRIPTION = "itc.containerlist.description";
	
	/** Document List Table title **/
	@RBEntry("Document List")
	public static final String DOCUMENT_LIST_TITLE = "itc.documentlist.title";

	/** Document List Table tool tip **/
	@RBEntry("Document List")
	public static final String DOCUMENT_LIST_TOOLTIP = "itc.documentlist.tooltip";

	/** Document List Table description **/
	@RBEntry("Document List")
	public static final String DOCUMENT_LIST_DESCRIPTION = "itc.documentlist.description";

	/** Document List Table title **/
	@RBEntry("Part List")
	public static final String PART_LIST_TITLE = "itc.partlist.title";

	/** Document List Table tool tip **/
	@RBEntry("Part List")
	public static final String PART_LIST_TOOLTIP = "itc.partlist.tooltip";

	/** Document List Table description **/
	@RBEntry("Part List")
	public static final String PART_LIST_DESCRIPTION = "itc.partlist.description";
	
	
	/** Object List Table title **/
	@RBEntry("Object List")
	public static final String OBJECT_LIST_TITLE = "itc.objectlist.title";

	/** Object List Table tool tip **/
	@RBEntry("Object List")
	public static final String OBJECT_LIST_TOOLTIP = "itc.objectlist.tooltip";

	/** Object List Table description **/
	@RBEntry("Object List")
	public static final String OBJECT_LIST_DESCRIPTION = "itc.objectlist.description";

}