package ext.test.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.test.resource.CustomMessageResource")

public final class CustomMessageResource extends WTListResourceBundle {


	  @RBEntry("Check the given number")
	  public static final String PRIVATE_CONSTANT_00 = "CHK_NUMBER";

	  @RBEntry("You dont have access to this object.Contact your administrator")
	  public static final String PRIVATE_CONSTANT_01 = "ACCESS_DENIED";
}
