package ext.test.listener;

import java.util.ArrayList;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManagerEvent;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.admin.ProjectPhase;
import wt.services.Manager;
import wt.services.ManagerException;
import wt.services.ManagerService;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.util.WTInvalidParameterException;
import wt.util.WTPropertyVetoException;
import com.ptc.projectmanagement.deliverable.PlanDeliverable;
import com.ptc.projectmanagement.plan.Plan;
import com.ptc.projectmanagement.plan.PlanActivity;
import com.ptc.projectmanagement.plan.ProjectManagementEvent;

/**
 * Listener to listen the percentage change in Activity of Deliverable or the
 * Activity itself.
 * @author 'true' 12805 kaushik.das@itcinfotech.com
 * @version 'true' 1.0
 */
public class DeliverablePercentChangeListenerService extends StandardManager
		implements DeliverablePercentChangeListener {
	/** Static filed to store serial version UID. **/
	private static final long serialVersionUID = -3624683044438080889L;
	/** Static filed to store class name. **/
	private static final String CLASSNAME = DeliverablePercentChangeListenerService.class
			.getName();
	/** Private variable for logger.**/
	private static final org.apache.log4j.Logger LOG = wt.log4j.LogR
			.getLogger(CLASSNAME);
	
	/**
	 * Method to create Object of
	 * {@link DeliverablePercentChangeListenerService}.
	 * 
	 * @return the object of {@link DeliverablePercentChangeListenerService}
	 * 
	 * @exception WTException
	 *                throws {@link WTException}
	 */
	public static DeliverablePercentChangeListenerService newDeliverablePercentChangeListenerService()
			throws WTException {
		DeliverablePercentChangeListenerService instance = new DeliverablePercentChangeListenerService();
		instance.initialize();
		return instance;
	}
	/**
	 * Synchronised method to perform start up process.
	 * 
	 * @exception ManagerException
	 *                throws {@link ManagerException}
	 */
	protected synchronized void performStartupProcess() throws ManagerException {
		getManagerService()
				.addEventListener(
						new ServiceEventListenerAdapter(CLASSNAME) {
							public void notifyVetoableEvent(Object event)
									throws WTException {
								listenForPercentChange(event);
							}
						},
						ProjectManagementEvent
					.generateEventKey(ProjectManagementEvent.EPP_PERCENT_CHANGE));
	}

	/**
	 * Get the class name.
	 * 
	 * @return the class name as a {@link String}
	 */
	@Override
	public String getName() {
		return CLASSNAME;
	}
	/**
	 * Get the start up type.
	 * 
	 * @return returns the Start Up type
	 */
	@Override
	public String getStartupType() {
		return Manager.STARTUP_AUTOMATIC;
	}
	/**
	 * Registering the event.
	 * 
	 * @param manager
	 *            {@link ManagerService} to register the event
	 */
	@Override
	public void registerEvents(ManagerService manager) {
		manager.addEventBranch(ProjectManagementEvent
				.generateEventKey(ProjectManagementEvent.EPP_PERCENT_CHANGE),
				ProjectManagementEvent.class.getName(),
				ProjectManagementEvent.EPP_PERCENT_CHANGE);
	}

	/**
	 * Implementation of listenForUsageLinkCreation.
	 * 
	 * @param event
	 *            event object
	 * 
	 * @exception WTException
	 *                throws {@link WTException}
	 */
	@Override
	public void listenForPercentChange(Object event) throws WTException {
		final Object eventObj = ((ProjectManagementEvent) event)
				.getEventTarget();
		LOG.debug(eventObj);
		/*
		 * Checking whether the eventObj is PlanActivity if true then fetching
		 * the corresponding Plan to check the percent complete
		 */
		if (eventObj instanceof PlanActivity) {
			PlanActivity planAc = (PlanActivity) eventObj;
			Plan plan = (Plan) planAc.getRoot();
			double percent = plan.getPercentWorkComplete();
			Project2 project = (Project2) plan.getContainerReference()
					.getObject();
			LOG.debug("Percent is " + percent);
			if (percent >= 20.00 && percent <= 40.00) {

				try {
					project.setPhase(ProjectPhase.PLANNING);
				} catch (WTPropertyVetoException e) {
					LOG.debug("Error generated for PLANNING" + e);
					e.printStackTrace();
				}
			} else if (percent >= 41.00 && percent <= 60.00) {
				try {
					project.setPhase(ProjectPhase.ASSIGNMENT);
				} catch (WTPropertyVetoException e) {
					LOG.debug("Error generated for ASSIGNMENT" + e);
					e.printStackTrace();
				}
			} else if (percent >= 61.00 && percent <= 80.00) {
				try {
					project.setPhase(ProjectPhase.DEVELOPMENT);
				} catch (WTPropertyVetoException e) {
					LOG.debug("Error generated for DEVELOPMENT" + e);
					e.printStackTrace();
				}
			} else if (percent >= 81.00 && percent <= 90.00) {
				ProjectPhase[] phase = ProjectPhase.getProjectPhaseSet();
				ProjectPhase phToSet = null;
				for (ProjectPhase ph : phase) {
					if (ph.getStringValue().contains("ANALYSIS")) {
						/*
						 * Analysis is the name of a custom ProjectPhase added
						 * using enumCustomize utility
						 */
						phToSet = ph;
						break;
					}
				}
				try {
					if (phToSet != null) {
						project.setPhase(phToSet);
					}
				} catch (WTInvalidParameterException e) {
					LOG.debug("Error generated for ANALYSIS" + e);
					e.printStackTrace();
				} catch (WTPropertyVetoException e) {
					LOG.debug("Error generated for ANALYSIS" + e);
					e.printStackTrace();
				}
			} else if (percent == 100.00) {
				try {
					project.setPhase(ProjectPhase.COMPLETED);
				} catch (WTPropertyVetoException e) {
					LOG.debug("Error generated for COMPLETED" + e);
					e.printStackTrace();
				}
			}
			PersistenceHelper.manager.modify(project);
		}
	}
} // Register the listener using the same way described in previous example

