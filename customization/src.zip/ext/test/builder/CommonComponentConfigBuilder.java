package ext.test.builder;

import wt.util.WTException;

import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;

//@ComponentBuilder("ext.test.builder.CommonComponentConfigBuilder")
/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
public abstract class CommonComponentConfigBuilder extends AbstractComponentBuilder{
	
	/**
	 * @param arg0
	 * @return
	 * @throws WTException
	 *//*
	@Override
	public ConfigurableTable buildConfigurableTable(String arg0)
			throws WTException {
		System.out.println("Calling configurable table");
		return new ConfigurableTableForPartAndDocumentViews();
	}*/

	@Override
	abstract public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1)
			throws Exception ;

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0)
			throws WTException {
		final ComponentConfigFactory componentConfig = getComponentConfigFactory();
		final TableConfig tableConfig = componentConfig
				.newTableConfig();
		//tableConfig.setId("ext.test.builder.CommonComponentConfigBuilder");
		tableConfig.setLabel("Custom Table");
		tableConfig.setShowCount(true);
		tableConfig.setSelectable(true);
		tableConfig.setSelectable(false);
		tableConfig.setConfigurable(false);
		tableConfig.setSingleSelect(false);
		tableConfig.setActionModel("part_report_toolbar_actions");
		tableConfig.addComponent(componentConfig.newColumnConfig("type_icon",
				true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"view.id", true));
		final ColumnConfig localColumnConfig1 = componentConfig
				.newColumnConfig("name", true);
		localColumnConfig1.setWidth(50);
		localColumnConfig1.setInfoPageLink(true);
		tableConfig.addComponent(localColumnConfig1);
		final ColumnConfig localColumnConfig2 = componentConfig
				.newColumnConfig("ownership.owner", true);
		localColumnConfig2.setWidth(50);
		tableConfig.addComponent(localColumnConfig2);
		tableConfig
				.addComponent(componentConfig.newColumnConfig("orgid", true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"infoPageAction", false));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"statusFamily_Share", false));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"statusFamily_General", false));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"statusFamily_Change", false));
		tableConfig.addComponent(componentConfig.newColumnConfig("version",
				true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"thePersistInfo.modifyStamp", true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"containerName", true));
		final ColumnConfig localColumnConfig3 = componentConfig
				.newColumnConfig("state", true);
		localColumnConfig3.setInfoPageLink(true);
		tableConfig.addComponent(localColumnConfig3);
		return tableConfig;
	}
	
	

}
