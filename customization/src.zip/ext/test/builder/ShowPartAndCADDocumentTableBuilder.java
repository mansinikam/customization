package ext.test.builder;

import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.NON_SELECTABLE_COLUMN;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.STRIKETHROUGH_COLUMN;
import wt.util.WTException;

import com.ptc.mvc.components.AbstractComponentConfigBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentBuilderType;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
@ComponentBuilder(value = "custom.table", type = ComponentBuilderType.CONFIG_ONLY)
public class ShowPartAndCADDocumentTableBuilder extends
		AbstractComponentConfigBuilder {

	
	
	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0)
			throws WTException {
		final ComponentConfigFactory componentConfig = getComponentConfigFactory();
		final TableConfig tableConfig = componentConfig.newTableConfig();
		tableConfig.setLabel("My Custom Table");
		tableConfig.setId("custom.table");

		tableConfig.setSelectable(true);
		tableConfig.setConfigurable(false);
		tableConfig.setSingleSelect(false);
		tableConfig.setActionModel("part_report_toolbar_actions");
		tableConfig.addComponent(componentConfig.newColumnConfig("type_icon",
				true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"infoPageActionAttachment", true));
		final ColumnConfig localColumnConfig1 = componentConfig
				.newColumnConfig("name", true);
		localColumnConfig1.setWidth(50);
		localColumnConfig1.setInfoPageLink(true);
		tableConfig.addComponent(localColumnConfig1);
		final ColumnConfig localColumnConfig2 = componentConfig
				.newColumnConfig("number", true);
		localColumnConfig2.setWidth(50);
		tableConfig.addComponent(localColumnConfig2);
		tableConfig
				.addComponent(componentConfig.newColumnConfig("orgid", true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"infoPageAction", true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"statusFamily_Share", false));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"statusFamily_General", false));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"statusFamily_Change", false));
		tableConfig.addComponent(componentConfig.newColumnConfig("version",
				true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"thePersistInfo.modifyStamp", true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"containerName", true));
		final ColumnConfig localColumnConfig3 = componentConfig
				.newColumnConfig("state", true);
		localColumnConfig3.setInfoPageLink(true);
		tableConfig.addComponent(localColumnConfig3);
		
		
		final ColumnConfig endItem = componentConfig
				.newColumnConfig("endItem", true);
		endItem.setLabel("End Item");
		endItem.setInfoPageLink(true);
		endItem.setHidden(true);
		tableConfig.addComponent(endItem);
		
		
		/* To make non-selectable row */
		
		/*ColumnConfig col = componentConfig.newColumnConfig (NON_SELECTABLE_COLUMN,  false);
		col.setNeed ("endItem"); 
		 Specify the attribute which will decide the row is
		  selectable or not.
		col.setDataStoreOnly(true);
		tableConfig.addComponent (col);
		tableConfig.setNonSelectableColumn (col);*/
		
		/* To make strke through row */
		
		ColumnConfig col = componentConfig.newColumnConfig (STRIKETHROUGH_COLUMN,  false);
		col.setNeed ("endItem"); 
		 /*Specify the attribute which will decide the row is
		  selectable or not.*/
		col.setDataStoreOnly(true);
		tableConfig.addComponent (col);
		tableConfig.setStrikeThroughColumn(col) ;
		
		/* Non-selectable column based on the state value */
		ColumnConfig statecol = componentConfig.newColumnConfig (NON_SELECTABLE_COLUMN,  false);
		statecol.setNeed ("state"); 
		 /*Specify the attribute which will decide the row is
		  selectable or not.*/
		statecol.setDataStoreOnly(true);
		statecol.setDataUtilityId("customstatestrikethroughcolumn");
		tableConfig.addComponent(statecol);
		tableConfig.setNonSelectableColumn(statecol);
		
		tableConfig.setHelpContext("WCCG_UICust_PresentInfoUI_ConstructRender");
		
		return tableConfig;
	}
}
