package ext.test.builder;

import java.util.ArrayList;
import java.util.List;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.inf.container.ContainerSpec;
import wt.inf.container.WTContainerHelper;
import wt.inf.library.WTLibrary;
import wt.pdmlink.PDMLinkProduct;
import wt.projmgmt.admin.Project2;
import wt.util.WTException;

import com.ptc.jca.mvc.components.JcaColumnConfig;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;

@ComponentBuilder("ext.test.builder.ContainerListBuilder")
public class ContainerListBuilder extends AbstractComponentBuilder {

	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1)
			throws WTException {
		final List<Persistable> data = new ArrayList<Persistable>();
		final QueryResult localQueryResult = WTContainerHelper.service
				.getContainers(new ContainerSpec(new Class[] {
						PDMLinkProduct.class, Project2.class, WTLibrary.class }));
		while (localQueryResult.hasMoreElements()) {
			data.add((Persistable) localQueryResult.nextElement());
		}
		return data;
	}

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0)
			throws WTException {
		final String str = "ProductsHelp";
		final ComponentConfigFactory localComponentConfigFactory = getComponentConfigFactory();
		final TableConfig localTableConfig = localComponentConfigFactory
				.newTableConfig();
		localTableConfig.setId("ext.test.builder.ContainerListBuilder");
		localTableConfig.setLabel("Custom Container List Table");
		localTableConfig.setHelpContext(str);
		localTableConfig.setShowCount(true);
		
		final ColumnConfig localColumnConfig1 = localComponentConfigFactory
				.newColumnConfig("name", true);
		localColumnConfig1.setWidth(50);
		localColumnConfig1.setInfoPageLink(true);
		localColumnConfig1.setSortable(true);
		localTableConfig.addComponent(localColumnConfig1);
		
		final ColumnConfig localColumnConfig2 = localComponentConfigFactory
				.newColumnConfig("infoPageAction", false);
		localColumnConfig2.setSortable(false);
		localTableConfig.addComponent(localColumnConfig2);
		
		
		final ColumnConfig localColumnConfig3 = localComponentConfigFactory
				.newColumnConfig("nmActions", false);
		localColumnConfig3.setSortable(false);
		localTableConfig.addComponent(localColumnConfig3);
		final ColumnConfig localColumnConfig4 = localComponentConfigFactory
				.newColumnConfig("containerInfo.owner", false);
		localColumnConfig4.setLabel("Owner");
		localColumnConfig4.setSortable(true);
		localTableConfig.addComponent(localColumnConfig4);
		final ColumnConfig localColumnConfig5 = localComponentConfigFactory
				.newColumnConfig("orgid", true);
		localColumnConfig5.setSortable(true);
		localTableConfig.addComponent(localColumnConfig5);
		final ColumnConfig localColumnConfig6 = localComponentConfigFactory
				.newColumnConfig("type", false);
		localColumnConfig6.setSortable(false);
		localTableConfig.addComponent(localColumnConfig6);
		final ColumnConfig localColumnConfig7 = localComponentConfigFactory
				.newColumnConfig("thePersistInfo.modifyStamp", true);
		localColumnConfig7.setSortable(true);
		localTableConfig.addComponent(localColumnConfig7);
		final ColumnConfig localColumnConfig8 = localComponentConfigFactory
				.newColumnConfig("containerInfo.description", true);
		((JcaColumnConfig) localColumnConfig8).setVariableHeight(true);
		localColumnConfig8.setSortable(true);
		localColumnConfig8.setLabel("Description");
		localTableConfig.addComponent(localColumnConfig8);
		final ColumnConfig localColumnConfig9 = localComponentConfigFactory
				.newColumnConfig("containerInfo.creator", true);
		localColumnConfig9.setSortable(true);
		localTableConfig.addComponent(localColumnConfig9);
		localColumnConfig9.setLabel("Creator");
		final ColumnConfig localColumnConfig10 = localComponentConfigFactory
				.newColumnConfig("thePersistInfo.createStamp", true);
		localColumnConfig10.setSortable(true);
		localTableConfig.addComponent(localColumnConfig10);
		final ColumnConfig localColumnConfig = localComponentConfigFactory
				.newColumnConfig("containerInfo.privateAccess", true);
		localColumnConfig.setSortable(true);
		localColumnConfig.setLabel("Private Access");
		localTableConfig.addComponent(localColumnConfig);
		return localTableConfig;
	}
}


