package ext.test.builder;

import wt.doc.WTDocument;

import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.netmarkets.util.beans.NmCommandBean;

@ComponentBuilder("ext.test.builder.ShowAllDocTableBuilder")
public class ShowAllDocTableBuilder extends CommonComponentConfigBuilder {
	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1)
			throws Exception {
		final NmCommandBean localNmCommandBean = ((JcaComponentParams) arg1)
				.getHelperBean().getNmCommandBean();
		final String productName = localNmCommandBean.getContainer().getName();
		
		return TableBuilderHelper.getObjectByProduct(WTDocument.class, productName);
	}
}
