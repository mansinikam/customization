/**
 * 
 */
package ext.test.builder;

import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.NON_SELECTABLE_COLUMN;
import wt.util.WTException;

import com.ptc.core.htmlcomp.components.AbstractConfigurableTableBuilder;
import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;





/**
 * Class to create a tree.
 * 
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */

@ComponentBuilder("ext.test.builder.PartStructureBuilder")
public class PartStructureBuilder extends AbstractConfigurableTableBuilder{
/*
 * In order to craete a tree typically we used to extend AbstractConfigurableTableBuilder 
 * which contains three unimplemented method buildConfigurableTable (Responsible for view),
 * buildComponentData (Responsible for the data) and buildComponentConfig (Responsible for the columns).
 * 
 */
	
	/**
	 * Private variable for Logger.
	 */
	private static final org.apache.log4j.Logger LOG = wt.log4j.LogR
			.getLogger(PartStructureBuilder.class.getName());
	
	/**
	 * To create the view in our tree.
	 * 
	 * @param arg0
	 * 
	 * @return 
	 * 
	 * @throws WTException
	 */
	@Override
	public ConfigurableTable buildConfigurableTable(String arg0)
			throws WTException {
		System.out.println("the value of String inside buildconfigurabletable : " + arg0);
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @return
	 * @throws Exception
	 */
	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1)
			throws Exception {
		/*
		 * Creating the data.
		 */
		return new PartStructureTreeHandlerAdapter();
	}

	/**
	 * @param arg0
	 * @return
	 * @throws WTException
	 */
	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0)
			throws WTException {
		final ComponentConfigFactory componentConfig = getComponentConfigFactory();
		final TableConfig tableConfig = componentConfig
				.newTableConfig();
		tableConfig.setId("ext.test.builder.PartStructureBuilder");
		tableConfig.setLabel("Custom Tree");
		tableConfig.setShowCount(true);
		tableConfig.setSelectable(true);
		
		tableConfig.setSingleSelect(false);
		tableConfig.setActionModel("part_report_toolbar_actions");
		tableConfig.addComponent(componentConfig.newColumnConfig("type_icon",
				true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"number", true));
		final ColumnConfig localColumnConfig1 = componentConfig
				.newColumnConfig("name", true);
		localColumnConfig1.setWidth(50);
		localColumnConfig1.setInfoPageLink(true);
		tableConfig.addComponent(localColumnConfig1);
		final ColumnConfig localColumnConfig2 = componentConfig
				.newColumnConfig("creatorName", true);
		localColumnConfig2.setWidth(50);
		localColumnConfig2.setLabel("Created By");
		tableConfig.addComponent(localColumnConfig2);
		
		tableConfig.addComponent(componentConfig.newColumnConfig("version",
				true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"thePersistInfo.modifyStamp", true));
		ColumnConfig conf = componentConfig.newColumnConfig(
				"ViewName", true);
		conf.setLabel("View Name");
		tableConfig.addComponent(conf);
		final ColumnConfig localColumnConfig3 = componentConfig
				.newColumnConfig("state", true);
		localColumnConfig3.setInfoPageLink(true);
		tableConfig.addComponent(localColumnConfig3);
		
		/* Non-selectable column based on the view value */
		ColumnConfig viewcol = componentConfig.newColumnConfig (NON_SELECTABLE_COLUMN,  false);
		viewcol.setNeed ("endItem"); 
		 /*Specify the attribute which will decide the row is
		  selectable or not.*/
		viewcol.setDataStoreOnly(false);
		viewcol.setHidden(true);
		tableConfig.addComponent(viewcol);
		tableConfig.setNonSelectableColumn(viewcol);
		
		tableConfig.setHelpContext("WCCG_UICust_PresentInfoUI_ConstructRender");
		return tableConfig;
	}
	
}
