/**
 * 
 */
package ext.test.builder;

import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.NON_SELECTABLE_COLUMN;
import wt.folder.Folder;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;

import com.infoengine.SAK.Task;
import com.ptc.core.components.util.OidHelper;
import com.ptc.mvc.components.AbstractComponentConfigBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentDataBuilder;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;

/**
 * @author 'true' kaushik.das@itcinfotech.com
 * 
 * @version 'true' 1
 */
@ComponentBuilder("part.doc.ie")
public class PartDocumentBuilderWithIE extends AbstractComponentConfigBuilder implements ComponentDataBuilder{

	
	
	public Object buildComponentData(ComponentConfig aComponentConfig, ComponentParams localComponentParam)
			throws Exception {
		System.out.println("Calling");
		//IeTaskInfo localIeTaskInfo =  new IeTaskInfo("search-ObjectCustom");
		Object contextObject = localComponentParam.getContextObject();
		
		Task task = new Task("/ext/customization/Search-Object.xml");
		
		task.setParam("search_type", "wt.part.WTPart");
		/*
		 * For multiple value in a single param use addParam method.
		 */
		//task.addParam("search_type", "wt.doc.WTDocument");
		WTContainer container = null;
		
		if (contextObject != null && (contextObject instanceof Folder)) {
			container = ((Folder)contextObject).getContainer();
			
		}
		else{
			container = WTContainerHelper.service
					.getExchangeContainer();
		}
		
		String id = OidHelper.getOidAsString(container);
		System.out.println(id);
		SessionServerHelper.manager.setAccessEnforced(false);
		
		task.setParam("container", id);
		task.invoke();
		SessionServerHelper.manager.setAccessEnforced(true);
		
		return task.getGroup("output").getElementList();
	}

	
	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0)
			throws WTException {
		final ComponentConfigFactory componentConfig = getComponentConfigFactory();
		final TableConfig tableConfig = componentConfig
				.newTableConfig();
		tableConfig.setId("part.doc.ie");
		tableConfig.setLabel("Custom Table (I*E)");
		tableConfig.setShowCount(true);
		tableConfig.setSelectable(true);
		
		tableConfig.setSingleSelect(false);
		tableConfig.setActionModel("part_report_toolbar_actions");
		tableConfig.addComponent(componentConfig.newColumnConfig("type_icon",
				true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"number", true));
		final ColumnConfig localColumnConfig1 = componentConfig
				.newColumnConfig("name", true);
		localColumnConfig1.setWidth(50);
		localColumnConfig1.setInfoPageLink(true);
		tableConfig.addComponent(localColumnConfig1);
		final ColumnConfig localColumnConfig2 = componentConfig
				.newColumnConfig("creatorName", true);
		localColumnConfig2.setWidth(50);
		localColumnConfig2.setLabel("Created By");
		tableConfig.addComponent(localColumnConfig2);
		
		tableConfig.addComponent(componentConfig.newColumnConfig("version",
				true));
		tableConfig.addComponent(componentConfig.newColumnConfig(
				"thePersistInfo.modifyStamp", true));
		ColumnConfig conf = componentConfig.newColumnConfig(
				"ViewName", true);
		conf.setLabel("View Name");
		tableConfig.addComponent(conf);
		final ColumnConfig localColumnConfig3 = componentConfig
				.newColumnConfig("state", true);
		localColumnConfig3.setInfoPageLink(true);
		tableConfig.addComponent(localColumnConfig3);
		
		/* Non-selectable column based on the view value */
		ColumnConfig viewcol = componentConfig.newColumnConfig (NON_SELECTABLE_COLUMN,  false);
		viewcol.setNeed ("ViewName"); 
		 /*Specify the attribute which will decide the row is
		  selectable or not.*/
		viewcol.setDataStoreOnly(false);
		viewcol.setHidden(true);
		viewcol.setDataUtilityId("customviewnonselectablecolumn");
		tableConfig.addComponent(viewcol);
		tableConfig.setNonSelectableColumn(viewcol);
		
		tableConfig.setHelpContext("WCCG_UICust_PresentInfoUI_ConstructRender");
		return tableConfig;
	}
}
